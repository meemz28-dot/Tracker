import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Calendar, CheckCircle, Clock, AlertCircle, Users, Server, Shield, Rocket, BarChart3, FileText, Building2, Zap, Plus, Trash2, Palette, Image, Database, Settings } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import eEnterpriseLogo from './assets/e_enterprise_logo.jpeg'
import { ProjectManagerAuth } from './components/ProjectManagerAuth.jsx'
import { EditableText, EditableNumber, EditableSelect, EditableDate } from './components/EditableField.jsx'
import PINAuth from './components/PINAuth.jsx'
import NotificationSystem from './components/NotificationSystem.jsx'
import InteractiveCharts from './components/InteractiveCharts.jsx'
import SearchAndFilter from './components/SearchAndFilter.jsx'
import UserManagement from './components/UserManagement.jsx'
import EnhancedAdminSettings from './components/EnhancedAdminSettings.jsx'
import EnhancedProjectManager from './components/EnhancedProjectManager.jsx'
import AdvancedDashboard from './components/AdvancedDashboard.jsx'
import './App.css'

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authenticatedUser, setAuthenticatedUser] = useState('')
  const [currentPhase, setCurrentPhase] = useState('legal')
  const [isEditMode, setIsEditMode] = useState(false)
  const [overallProgress, setOverallProgress] = useState(35)
  const [filteredData, setFilteredData] = useState([])

  // Project data state
  const [projectTitle, setProjectTitle] = useState('OneCloud Launch Tracker')
  const [projectSubtitle, setProjectSubtitle] = useState('Next Generation Sovereign Hyperscale Cloud')

  // Project phases with detailed tracking
  const [phases, setPhases] = useState([
    {
      id: 'po',
      name: 'Purchase Order',
      status: 'completed',
      progress: 100,
      startDate: '2024-01-15',
      endDate: '2024-02-01',
      description: 'Contract finalization and purchase order processing',
      responsiblePerson: 'Munther Altawash',
      responsibleFunction: 'Procurement Manager',
      tasks: [
        { name: 'Contract Review', status: 'completed', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Legal Counsel' },
        { name: 'PO Generation', status: 'completed', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Procurement Manager' },
        { name: 'Budget Approval', status: 'completed', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Finance Director' },
        { name: 'Vendor Onboarding', status: 'completed', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Vendor Relations' }
      ]
    },
    {
      id: 'legal',
      name: 'Legal & Compliance',
      status: 'in-progress',
      progress: 75,
      startDate: '2024-02-01',
      endDate: '2024-03-15',
      description: 'Legal documentation, compliance verification, and regulatory approvals',
      responsiblePerson: 'Munther Altawash',
      responsibleFunction: 'Chief Legal Officer',
      tasks: [
        { name: 'Data Protection Agreement', status: 'completed', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Legal Counsel' },
        { name: 'Compliance Audit', status: 'completed', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Compliance Officer' },
        { name: 'Regulatory Approvals', status: 'in-progress', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Regulatory Affairs' },
        { name: 'Security Clearance', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Security Director' }
      ]
    },
    {
      id: 'dc-readiness',
      name: 'Data Center Readiness',
      status: 'pending',
      progress: 0,
      startDate: '2024-03-15',
      endDate: '2024-05-30',
      description: 'Infrastructure setup, hardware installation, and network configuration',
      responsiblePerson: 'Munther Altawash',
      responsibleFunction: 'Infrastructure Director',
      tasks: [
        { name: 'Hardware Procurement', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Infrastructure Director' },
        { name: 'DC Space Allocation', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Facilities Manager' },
        { name: 'Network Setup', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Network Architect' },
        { name: 'Power & Cooling', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'DC Operations Manager' }
      ]
    },
    {
      id: 'service-launch',
      name: 'Service Launch',
      status: 'pending',
      progress: 0,
      startDate: '2024-05-30',
      endDate: '2024-07-15',
      description: 'Platform deployment, testing, and service activation',
      responsiblePerson: 'Munther Altawash',
      responsibleFunction: 'Cloud Platform Director',
      tasks: [
        { name: 'Platform Deployment', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Cloud Platform Director' },
        { name: 'Security Testing', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Security Director' },
        { name: 'Performance Testing', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'QA Lead' },
        { name: 'Go-Live Preparation', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Operations Manager' }
      ]
    },
    {
      id: 'post-launch',
      name: 'Post Launch',
      status: 'pending',
      progress: 0,
      startDate: '2024-07-15',
      endDate: '2024-09-30',
      description: 'Monitoring, optimization, and customer onboarding',
      responsiblePerson: 'Munther Altawash',
      responsibleFunction: 'Operations Manager',
      tasks: [
        { name: 'Performance Monitoring', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Operations Manager' },
        { name: 'Customer Onboarding', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Customer Success Manager' },
        { name: 'Service Optimization', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Senior Engineer' },
        { name: 'Documentation', status: 'pending', responsiblePerson: 'Munther Altawash', responsibleFunction: 'Technical Writer' }
      ]
    }
  ])

  // Key metrics and KPIs - now as state
  const [metrics, setMetrics] = useState({
    totalServices: 150,
    dataCenters: 4,
    complianceCerts: 6,
    teamMembers: 45
  })

  // Enhanced user management
  const [users, setUsers] = useState([
    {
      id: 'admin_001',
      name: 'System Administrator',
      email: 'admin@eenterprise.com',
      role: 'admin',
      pin: '1234',
      isActive: true,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    },
    {
      id: 'pm_001',
      name: 'Project Manager',
      email: 'pm@eenterprise.com',
      role: 'editor',
      pin: '5678',
      isActive: true,
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    }
  ])

  const [currentUser, setCurrentUser] = useState(null)

  // Admin settings for visual customization
  const [adminSettings, setAdminSettings] = useState({
    primaryColor: '#E30613',
    secondaryColor: '#1B365D',
    accentColor: '#FFB81C',
    logoUrl: eEnterpriseLogo,
    companyName: 'e& enterprise',
    favicon: '/favicon.ico'
  })

  // Update admin settings
  const updateAdminSetting = (key, value) => {
    setAdminSettings(prev => ({ ...prev, [key]: value }))
  }

  // Update metric function
  const updateMetric = (key, value) => {
    setMetrics(prev => ({ ...prev, [key]: value }))
  }

  // Phase management functions
  const updatePhase = (phaseId, updates) => {
    setPhases(prev => prev.map(phase => 
      phase.id === phaseId 
        ? { ...phase, ...updates }
        : phase
    ))
  }

  const updateTask = (phaseId, taskIndex, updates) => {
    setPhases(prev => prev.map(phase => 
      phase.id === phaseId 
        ? { 
            ...phase, 
            tasks: phase.tasks.map((task, index) => 
              index === taskIndex ? { ...task, ...updates } : task
            )
          }
        : phase
    ))
  }

  const addTask = (phaseId) => {
    const newTask = {
      name: 'New Task',
      status: 'pending',
      responsiblePerson: 'Team Member',
      responsibleFunction: 'Role/Function'
    }
    setPhases(prev => prev.map(phase => 
      phase.id === phaseId 
        ? { ...phase, tasks: [...phase.tasks, newTask] }
        : phase
    ))
  }

  const removeTask = (phaseId, taskIndex) => {
    setPhases(prev => prev.map(phase => 
      phase.id === phaseId 
        ? { ...phase, tasks: phase.tasks.filter((_, index) => index !== taskIndex) }
        : phase
    ))
  }

  // Data persistence with localStorage
  useEffect(() => {
    const savedData = localStorage.getItem('onecloud-tracker-data')
    if (savedData) {
      try {
        const data = JSON.parse(savedData)
        setOverallProgress(data.overallProgress || 35)
        setProjectTitle(data.projectTitle || 'OneCloud Launch Tracker')
        setProjectSubtitle(data.projectSubtitle || 'Next Generation Sovereign Hyperscale Cloud')
        setPhases(data.phases || phases)
        setMetrics(data.metrics || metrics)
        setAdminSettings(data.adminSettings || adminSettings)
      } catch (error) {
        console.error('Error loading saved data:', error)
      }
    }
  }, [])

  // Save data whenever state changes
  useEffect(() => {
    const dataToSave = {
      overallProgress,
      projectTitle,
      projectSubtitle,
      phases,
      metrics,
      adminSettings,
      lastUpdated: new Date().toISOString()
    }
    localStorage.setItem('onecloud-tracker-data', JSON.stringify(dataToSave))
  }, [overallProgress, projectTitle, projectSubtitle, phases, metrics, adminSettings])

  // Manual save function
  const saveData = () => {
    const dataToSave = {
      overallProgress,
      projectTitle,
      projectSubtitle,
      phases,
      metrics,
      adminSettings,
      lastUpdated: new Date().toISOString()
    }
    localStorage.setItem('onecloud-tracker-data', JSON.stringify(dataToSave))
    
    // Show save confirmation (you could add a toast notification here)
    console.log('Data saved successfully')
  }

  // Reset to default data
  const resetData = () => {
    if (confirm('Are you sure you want to reset all data to defaults? This cannot be undone.')) {
      localStorage.removeItem('onecloud-tracker-data')
      window.location.reload()
    }
  }

  // Status options for dropdowns
  const statusOptions = [
    { value: 'pending', label: 'Pending' },
    { value: 'in-progress', label: 'In Progress' },
    { value: 'completed', label: 'Completed' },
    { value: 'blocked', label: 'Blocked' },
    { value: 'on-hold', label: 'On Hold' }
  ]

  // Mock data for charts
  const progressData = [
    { month: 'Jan', planned: 20, actual: 25 },
    { month: 'Feb', planned: 35, actual: 35 },
    { month: 'Mar', planned: 50, actual: 35 },
    { month: 'Apr', planned: 65, actual: 0 },
    { month: 'May', planned: 80, actual: 0 },
    { month: 'Jun', planned: 90, actual: 0 },
    { month: 'Jul', planned: 100, actual: 0 }
  ]

  const riskData = [
    { name: 'Low Risk', value: 60, color: '#10B981' },
    { name: 'Medium Risk', value: 25, color: '#F59E0B' },
    { name: 'High Risk', value: 15, color: '#EF4444' }
  ]

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'in-progress': return 'bg-blue-500'
      case 'pending': return 'bg-gray-400'
      case 'blocked': return 'bg-red-500'
      case 'on-hold': return 'bg-yellow-500'
      default: return 'bg-gray-400'
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed': return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case 'in-progress': return <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
      case 'pending': return <Badge className="bg-gray-100 text-gray-800">Pending</Badge>
      case 'blocked': return <Badge className="bg-red-100 text-red-800">Blocked</Badge>
      case 'on-hold': return <Badge className="bg-yellow-100 text-yellow-800">On Hold</Badge>
      default: return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>
    }
  }

  // Handle successful PIN authentication
  const handleAuthentication = (userLabel) => {
    setIsAuthenticated(true)
    setAuthenticatedUser(userLabel)
    
    // Find user by PIN or default to admin
    const user = users.find(u => u.pin === userLabel) || users.find(u => u.role === 'admin')
    if (user) {
      setCurrentUser(user)
      // Update last login
      setUsers(prev => prev.map(u => 
        u.id === user.id ? { ...u, lastLogin: new Date().toISOString() } : u
      ))
    }
  }

  // If not authenticated, show PIN authentication page
  if (!isAuthenticated) {
    return <PINAuth onAuthenticated={handleAuthentication} adminSettings={adminSettings} />
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b" style={{ backgroundColor: `${adminSettings.primaryColor}05` }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img 
                src={adminSettings.logoUrl} 
                alt={adminSettings.companyName} 
                className="h-12 w-auto object-contain" 
              />
              <div>
                {isEditMode ? (
                  <div className="space-y-1">
                    <EditableText
                      value={projectTitle}
                      onSave={setProjectTitle}
                      className="text-2xl font-bold"
                      style={{ color: adminSettings.primaryColor }}
                    />
                    <EditableText
                      value={projectSubtitle}
                      onSave={setProjectSubtitle}
                      className="text-sm text-gray-600"
                    />
                  </div>
                ) : (
                  <div>
                    <h1 
                      className="text-2xl font-bold" 
                      style={{ color: adminSettings.primaryColor }}
                    >
                      {projectTitle}
                    </h1>
                    <p className="text-sm text-gray-600">{projectSubtitle}</p>
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <NotificationSystem phases={phases} isEditMode={isEditMode} />
              
              <div className="text-right">
                <p className="text-sm text-gray-500">Authenticated as</p>
                <p className="text-sm font-medium" style={{ color: adminSettings.primaryColor }}>
                  {authenticatedUser}
                </p>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setIsAuthenticated(false)
                  setAuthenticatedUser('')
                  setIsEditMode(false)
                }}
                className="text-gray-600 hover:text-gray-800"
              >
                Logout
              </Button>
              
              <ProjectManagerAuth 
                isEditMode={isEditMode} 
                onToggleEditMode={setIsEditMode} 
              />
              {isEditMode && (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={saveData}
                    className="flex items-center space-x-1"
                    style={{ 
                      borderColor: adminSettings.accentColor, 
                      color: adminSettings.accentColor 
                    }}
                  >
                    <CheckCircle className="h-4 w-4" />
                    <span>Save Changes</span>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={resetData}
                    className="flex items-center space-x-1 text-red-600 hover:text-red-700"
                  >
                    <AlertCircle className="h-4 w-4" />
                    <span>Reset Data</span>
                  </Button>
                </div>
              )}
              <div className="text-right">
                <p className="text-sm text-gray-600">Overall Progress</p>
                {isEditMode ? (
                  <EditableNumber
                    value={overallProgress}
                    onSave={setOverallProgress}
                    min={0}
                    max={100}
                    suffix="%"
                    className="text-2xl font-bold"
                    style={{ color: adminSettings.primaryColor }}
                  />
                ) : (
                  <p 
                    className="text-2xl font-bold" 
                    style={{ color: adminSettings.primaryColor }}
                  >
                    {overallProgress}%
                  </p>
                )}
                <Progress value={overallProgress} className="w-24 mt-1" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Search & Filter</CardTitle>
            <CardDescription>Find specific phases, tasks, or team members</CardDescription>
          </CardHeader>
          <CardContent>
            <SearchAndFilter 
              phases={phases} 
              onFilterChange={setFilteredData}
              isEditMode={isEditMode}
            />
          </CardContent>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cloud Services</CardTitle>
              <Server className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isEditMode ? (
                <EditableNumber
                  value={metrics.totalServices}
                  onSave={(value) => updateMetric('totalServices', value)}
                  min={0}
                  max={1000}
                  suffix="+"
                  className="text-2xl font-bold"
                  style={{ color: adminSettings.primaryColor }}
                />
              ) : (
                <div className="text-2xl font-bold" style={{ color: adminSettings.primaryColor }}>
                  {metrics.totalServices}+
                </div>
              )}
              <p className="text-xs text-muted-foreground">Available at launch</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Data Centers</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isEditMode ? (
                <EditableNumber
                  value={metrics.dataCenters}
                  onSave={(value) => updateMetric('dataCenters', value)}
                  min={1}
                  max={20}
                  className="text-2xl font-bold"
                  style={{ color: adminSettings.primaryColor }}
                />
              ) : (
                <div className="text-2xl font-bold" style={{ color: adminSettings.primaryColor }}>
                  {metrics.dataCenters}
                </div>
              )}
              <p className="text-xs text-muted-foreground">UAE locations</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Compliance</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isEditMode ? (
                <EditableNumber
                  value={metrics.complianceCerts}
                  onSave={(value) => updateMetric('complianceCerts', value)}
                  min={1}
                  max={50}
                  className="text-2xl font-bold"
                  style={{ color: adminSettings.primaryColor }}
                />
              ) : (
                <div className="text-2xl font-bold" style={{ color: adminSettings.primaryColor }}>
                  {metrics.complianceCerts}
                </div>
              )}
              <p className="text-xs text-muted-foreground">Certifications</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Team Members</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isEditMode ? (
                <EditableNumber
                  value={metrics.teamMembers}
                  onSave={(value) => updateMetric('teamMembers', value)}
                  min={1}
                  max={500}
                  className="text-2xl font-bold"
                  style={{ color: adminSettings.primaryColor }}
                />
              ) : (
                <div className="text-2xl font-bold" style={{ color: adminSettings.primaryColor }}>
                  {metrics.teamMembers}
                </div>
              )}
              <p className="text-xs text-muted-foreground">Across all phases</p>
            </CardContent>
          </Card>
        </div>

        {/* Launch Timeline */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Rocket className="h-5 w-5" />
              <span>Launch Timeline</span>
            </CardTitle>
            <CardDescription>Track progress across all project phases</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {phases.map((phase, index) => (
                <div key={phase.id} className="flex items-start space-x-4">
                  <div className="flex flex-col items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${getStatusColor(phase.status)}`}>
                      {phase.status === 'completed' && <CheckCircle className="w-4 h-4 text-white" />}
                      {phase.status === 'in-progress' && <Clock className="w-4 h-4 text-white" />}
                      {phase.status === 'pending' && <Clock className="w-4 h-4 text-white" />}
                    </div>
                    {index < phases.length - 1 && (
                      <div className="w-px h-16 bg-gray-300 mt-2"></div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        {isEditMode ? (
                          <div className="space-y-2">
                            <EditableText
                              value={phase.name}
                              onSave={(value) => updatePhase(phase.id, { name: value })}
                              className="text-lg font-semibold"
                            />
                            <EditableText
                              value={phase.description}
                              onSave={(value) => updatePhase(phase.id, { description: value })}
                              className="text-sm text-gray-600"
                              multiline
                            />
                            <div className="flex space-x-4 text-xs text-gray-500">
                              <EditableDate
                                value={phase.startDate}
                                onSave={(value) => updatePhase(phase.id, { startDate: value })}
                              />
                              <span>-</span>
                              <EditableDate
                                value={phase.endDate}
                                onSave={(value) => updatePhase(phase.id, { endDate: value })}
                              />
                            </div>
                            <div className="space-y-1">
                              <EditableText
                                value={phase.responsiblePerson}
                                onSave={(value) => updatePhase(phase.id, { responsiblePerson: value })}
                                className="text-sm font-medium text-blue-600"
                              />
                              <EditableText
                                value={phase.responsibleFunction}
                                onSave={(value) => updatePhase(phase.id, { responsibleFunction: value })}
                                className="text-xs text-gray-500"
                              />
                            </div>
                          </div>
                        ) : (
                          <div>
                            <h3 className="text-lg font-semibold">{phase.name}</h3>
                            <p className="text-sm text-gray-600">{phase.description}</p>
                            <p className="text-xs text-gray-500 mt-1">
                              {phase.startDate} - {phase.endDate}
                            </p>
                            <div className="mt-2">
                              <p className="text-sm font-medium text-blue-600">{phase.responsiblePerson}</p>
                              <p className="text-xs text-gray-500">{phase.responsibleFunction}</p>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        {isEditMode ? (
                          <div className="space-y-2">
                            <EditableSelect
                              value={phase.status}
                              options={statusOptions}
                              onSave={(value) => updatePhase(phase.id, { status: value })}
                            />
                            <EditableNumber
                              value={phase.progress}
                              onSave={(value) => updatePhase(phase.id, { progress: value })}
                              min={0}
                              max={100}
                              suffix="% complete"
                              className="text-sm text-gray-600"
                            />
                          </div>
                        ) : (
                          <div>
                            {getStatusBadge(phase.status)}
                            <p className="text-sm text-gray-600 mt-1">{phase.progress}% complete</p>
                          </div>
                        )}
                        <div className="w-32 mt-2">
                          <Progress value={phase.progress} className="h-2" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Tabs with New Features */}
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="phases">Phase Details</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="admin">Admin Settings</TabsTrigger>
          </TabsList>

          {/* Enhanced Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <AdvancedDashboard 
              phases={phases}
              metrics={metrics}
              currentUser={currentUser}
              isEditMode={isEditMode}
              adminSettings={adminSettings}
              onMetricUpdate={updateMetric}
            />
          </TabsContent>

          {/* Enhanced Admin Settings */}
          <TabsContent value="admin" className="space-y-6">
            {isEditMode ? (
              <div className="space-y-6">
                {/* Project Manager Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Settings className="w-5 h-5" />
                      <span>Project Manager</span>
                    </CardTitle>
                    <CardDescription>
                      Advanced project management and task control
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <EnhancedProjectManager 
                      phases={phases}
                      setPhases={setPhases}
                      isEditMode={isEditMode}
                      currentUser={currentUser}
                      onPhaseUpdate={updatePhase}
                      onTaskUpdate={updateTask}
                      metrics={metrics}
                      setMetrics={setMetrics}
                    />
                  </CardContent>
                </Card>

                {/* User Management Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Users className="w-5 h-5" />
                      <span>User Management</span>
                    </CardTitle>
                    <CardDescription>
                      Manage team members, roles, and permissions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <UserManagement 
                      currentUser={currentUser}
                      users={users}
                      setUsers={setUsers}
                      onUserUpdate={() => {
                        localStorage.setItem('onecloud-users', JSON.stringify(users))
                      }}
                    />
                  </CardContent>
                </Card>

                {/* Admin Settings Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="w-5 h-5" />
                      <span>System Administration</span>
                    </CardTitle>
                    <CardDescription>
                      System configuration and administrative controls
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <EnhancedAdminSettings 
                      adminSettings={adminSettings}
                      setAdminSettings={setAdminSettings}
                      isEditMode={isEditMode}
                      currentUser={currentUser}
                      systemStats={{
                        uptime: '99.9%',
                        activeUsers: users.filter(u => u.isActive).length,
                        dataSize: '2.4 MB',
                        performance: 95
                      }}
                      onSettingsUpdate={(newSettings) => {
                        setAdminSettings(prev => ({
                          ...prev,
                          primaryColor: newSettings.appearance.primaryColor,
                          secondaryColor: newSettings.appearance.secondaryColor,
                          accentColor: newSettings.appearance.accentColor,
                          companyName: newSettings.branding.companyName,
                          logoUrl: newSettings.branding.logoUrl,
                          favicon: newSettings.branding.faviconUrl,
                          headerTitle: newSettings.branding.headerTitle,
                          footerText: newSettings.branding.footerText,
                        }))
                        localStorage.setItem(
                          'onecloud-admin-settings',
                          JSON.stringify(newSettings)
                        )
                      }}
                      onSystemAction={(action) => {
                        console.log('System action:', action)
                      }}
                    />
                  </CardContent>
                </Card>

                {/* Admin Settings Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Shield className="w-5 h-5" />
                      <span>System Administration</span>
                    </CardTitle>
                    <CardDescription>
                      System configuration and administrative controls
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <EnhancedAdminSettings 
                      adminSettings={adminSettings}
                      setAdminSettings={setAdminSettings}
                      isEditMode={isEditMode}
                      currentUser={currentUser}
                      systemStats={{
                        uptime: '99.9%',
                        activeUsers: users.filter(u => u.isActive).length,
                        dataSize: '2.4 MB',
                        performance: 95
                      }}
                      onSettingsUpdate={(newSettings) => {
                        setAdminSettings(prev => ({
                          ...prev,
                          primaryColor: newSettings.appearance.primaryColor,
                          secondaryColor: newSettings.appearance.secondaryColor,
                          accentColor: newSettings.appearance.accentColor,
                          companyName: newSettings.branding.companyName,
                          logoUrl: newSettings.branding.logoUrl,
                          favicon: newSettings.branding.faviconUrl,
                          headerTitle: newSettings.branding.headerTitle,
                          footerText: newSettings.branding.footerText,
                        }))
                        localStorage.setItem(
                          'onecloud-admin-settings',
                          JSON.stringify(newSettings)
                        )
                      }}
                      onSystemAction={(action) => {
                        console.log('System action:', action)
                      }}
                    />
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Admin Settings</CardTitle>
                  <CardDescription>
                    Enable edit mode to access admin settings, project management, and user management features
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    Admin settings, project management, and user management features are only accessible 
                    when the application is in Project Manager Mode. Please enable edit mode using the 
                    Project Manager button to access these advanced features.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Phase Details Tab */}
          <TabsContent value="phases" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {phases.map((phase) => (
                <Card key={phase.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      {isEditMode ? (
                        <EditableText
                          value={phase.name}
                          onSave={(value) => updatePhase(phase.id, { name: value })}
                          className="text-lg font-semibold"
                        />
                      ) : (
                        phase.name
                      )}
                      {isEditMode ? (
                        <EditableSelect
                          value={phase.status}
                          options={statusOptions}
                          onSave={(value) => updatePhase(phase.id, { status: value })}
                        />
                      ) : (
                        getStatusBadge(phase.status)
                      )}
                    </CardTitle>
                    <CardDescription>
                      {isEditMode ? (
                        <div className="space-y-2">
                          <EditableText
                            value={phase.description}
                            onSave={(value) => updatePhase(phase.id, { description: value })}
                            multiline
                          />
                          <div className="grid grid-cols-2 gap-2">
                            <EditableText
                              value={phase.responsiblePerson}
                              onSave={(value) => updatePhase(phase.id, { responsiblePerson: value })}
                              className="text-sm font-medium text-blue-600"
                              placeholder="Responsible Person"
                            />
                            <EditableText
                              value={phase.responsibleFunction}
                              onSave={(value) => updatePhase(phase.id, { responsibleFunction: value })}
                              className="text-sm text-gray-600"
                              placeholder="Function/Role"
                            />
                          </div>
                        </div>
                      ) : (
                        <div>
                          {phase.description}
                          <div className="mt-2 grid grid-cols-2 gap-2">
                            <p className="text-sm font-medium text-blue-600">{phase.responsiblePerson}</p>
                            <p className="text-sm text-gray-600">{phase.responsibleFunction}</p>
                          </div>
                        </div>
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {phase.tasks.map((task, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex-1">
                            {isEditMode ? (
                              <div className="space-y-1">
                                <EditableText
                                  value={task.name}
                                  onSave={(value) => updateTask(phase.id, index, { name: value })}
                                  className="font-medium"
                                />
                                <div className="grid grid-cols-2 gap-2">
                                  <EditableText
                                    value={task.responsiblePerson}
                                    onSave={(value) => updateTask(phase.id, index, { responsiblePerson: value })}
                                    className="text-sm text-blue-600"
                                    placeholder="Person"
                                  />
                                  <EditableText
                                    value={task.responsibleFunction}
                                    onSave={(value) => updateTask(phase.id, index, { responsibleFunction: value })}
                                    className="text-sm text-gray-600"
                                    placeholder="Function"
                                  />
                                </div>
                              </div>
                            ) : (
                              <div>
                                <p className="font-medium">{task.name}</p>
                                <div className="grid grid-cols-2 gap-2">
                                  <p className="text-sm text-blue-600">{task.responsiblePerson}</p>
                                  <p className="text-sm text-gray-600">{task.responsibleFunction}</p>
                                </div>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            {isEditMode ? (
                              <>
                                <EditableSelect
                                  value={task.status}
                                  options={statusOptions}
                                  onSave={(value) => updateTask(phase.id, index, { status: value })}
                                />
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => removeTask(phase.id, index)}
                                  className="text-red-600 hover:text-red-700"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </>
                            ) : (
                              getStatusBadge(task.status)
                            )}
                          </div>
                        </div>
                      ))}
                      {isEditMode && (
                        <Button
                          onClick={() => addTask(phase.id)}
                          variant="outline"
                          className="w-full"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add Task
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <InteractiveCharts phases={phases} overallProgress={overallProgress} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

export default App

