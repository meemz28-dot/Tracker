// Example modifications for the OneCloud Launch Tracker
// This file demonstrates common customizations you can make

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Calendar, CheckCircle, Clock, AlertCircle, Users, Server, Shield, Rocket, BarChart3, FileText, Building2, Zap, Target, TrendingUp } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts'
import eEnterpriseLogo from './assets/e_enterprise_logo.jpeg'
import './App.css'

function AppWithModifications() {
  // EXAMPLE 1: Updated progress and current phase
  const [currentPhase, setCurrentPhase] = useState('dc-readiness') // Changed from 'legal'
  const [overallProgress, setOverallProgress] = useState(55) // Updated from 35%

  // EXAMPLE 2: Updated metrics with new values
  const metrics = {
    totalServices: 175, // Increased from 150
    datacenters: 5,     // Increased from 4
    complianceCertifications: 8, // Increased from 6
    teamMembers: 52,    // Increased from 45
    milestonesCompleted: 18, // Increased from 12
    totalMilestones: 34,
    // EXAMPLE 3: New metrics added
    budgetUtilization: 65,
    riskScore: 23
  }

  // EXAMPLE 4: Updated phases with new statuses and progress
  const phases = [
    {
      id: 'po',
      name: 'Purchase Order',
      status: 'completed',
      progress: 100,
      startDate: '2024-01-15',
      endDate: '2024-02-01',
      description: 'Contract finalization and purchase order processing',
      tasks: [
        { name: 'Contract Review', status: 'completed', assignee: 'Legal Team' },
        { name: 'PO Generation', status: 'completed', assignee: 'Procurement' },
        { name: 'Budget Approval', status: 'completed', assignee: 'Finance' },
        { name: 'Vendor Onboarding', status: 'completed', assignee: 'Vendor Management' }
      ]
    },
    {
      id: 'legal',
      name: 'Legal & Compliance',
      status: 'completed', // Changed from 'in-progress'
      progress: 100,      // Changed from 75
      startDate: '2024-02-01',
      endDate: '2024-03-15',
      description: 'Legal documentation, compliance verification, and regulatory approvals',
      tasks: [
        { name: 'Data Protection Agreement', status: 'completed', assignee: 'Legal Team' },
        { name: 'Compliance Audit', status: 'completed', assignee: 'Compliance Officer' },
        { name: 'Regulatory Approvals', status: 'completed', assignee: 'Regulatory Affairs' }, // Changed from 'in-progress'
        { name: 'Security Clearance', status: 'completed', assignee: 'Security Team' } // Changed from 'pending'
      ]
    },
    {
      id: 'dc-readiness',
      name: 'Data Center Readiness',
      status: 'in-progress', // Changed from 'pending'
      progress: 40,          // Changed from 0
      startDate: '2024-03-15',
      endDate: '2024-05-30',
      description: 'Infrastructure setup, hardware installation, and network configuration',
      tasks: [
        { name: 'Hardware Procurement', status: 'completed', assignee: 'Infrastructure Team' }, // Changed from 'pending'
        { name: 'DC Space Allocation', status: 'completed', assignee: 'Facilities' }, // Changed from 'pending'
        { name: 'Network Setup', status: 'in-progress', assignee: 'Network Team' }, // Changed from 'pending'
        { name: 'Power & Cooling', status: 'pending', assignee: 'DC Operations' }
      ]
    },
    {
      id: 'service-launch',
      name: 'Service Launch',
      status: 'pending',
      progress: 0,
      startDate: '2024-05-30',
      endDate: '2024-07-15',
      description: 'Platform deployment, testing, and service activation',
      tasks: [
        { name: 'Platform Deployment', status: 'pending', assignee: 'Cloud Team' },
        { name: 'Security Testing', status: 'pending', assignee: 'Security Team' },
        { name: 'Performance Testing', status: 'pending', assignee: 'QA Team' },
        { name: 'Go-Live Preparation', status: 'pending', assignee: 'Operations' }
      ]
    },
    {
      id: 'post-launch',
      name: 'Post Launch',
      status: 'pending',
      progress: 0,
      startDate: '2024-07-15',
      endDate: '2024-09-30',
      description: 'Monitoring, optimization, and customer onboarding',
      tasks: [
        { name: 'Performance Monitoring', status: 'pending', assignee: 'Operations' },
        { name: 'Customer Onboarding', status: 'pending', assignee: 'Customer Success' },
        { name: 'Service Optimization', status: 'pending', assignee: 'Engineering' },
        { name: 'Documentation', status: 'pending', assignee: 'Technical Writing' }
      ]
    }
  ]

  // EXAMPLE 5: Updated timeline data with more recent progress
  const timelineData = [
    { month: 'Jan', planned: 20, actual: 22 },
    { month: 'Feb', planned: 35, actual: 38 },
    { month: 'Mar', planned: 50, actual: 55 },
    { month: 'Apr', planned: 65, actual: 58 }, // Updated with actual progress
    { month: 'May', planned: 80, actual: 0 },
    { month: 'Jun', planned: 90, actual: 0 },
    { month: 'Jul', planned: 100, actual: 0 }
  ]

  // EXAMPLE 6: Updated risk distribution
  const riskData = [
    { name: 'Low Risk', value: 70, color: '#10B981' }, // Improved from 60
    { name: 'Medium Risk', value: 20, color: '#F59E0B' }, // Reduced from 25
    { name: 'High Risk', value: 10, color: '#EF4444' }   // Reduced from 15
  ]

  // EXAMPLE 7: Enhanced status functions with new statuses
  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'in-progress': return 'bg-blue-500'
      case 'pending': return 'bg-gray-400'
      case 'blocked': return 'bg-red-500'      // New status
      case 'on-hold': return 'bg-yellow-500'   // New status
      default: return 'bg-gray-400'
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'completed': return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case 'in-progress': return <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
      case 'pending': return <Badge className="bg-gray-100 text-gray-800">Pending</Badge>
      case 'blocked': return <Badge className="bg-red-100 text-red-800">Blocked</Badge>
      case 'on-hold': return <Badge className="bg-yellow-100 text-yellow-800">On Hold</Badge>
      default: return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header with updated progress */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <img src={eEnterpriseLogo} alt="e& enterprise" className="h-12 w-auto" />
              <div>
                {/* EXAMPLE 8: Updated title */}
                <h1 className="text-2xl font-bold text-gray-900">OneCloud Launch Tracker - Updated</h1>
                <p className="text-sm text-gray-600">Next Generation Sovereign Hyperscale Cloud - Phase 3</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-gray-600">Overall Progress</p>
                <p className="text-2xl font-bold text-red-600">{overallProgress}%</p>
              </div>
              <div className="w-32">
                <Progress value={overallProgress} className="h-3" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content with updated metrics */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-6 gap-6 mb-8"> {/* Changed from grid-cols-4 to grid-cols-6 */}
          {/* Existing metrics cards */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Cloud Services</CardTitle>
              <Server className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{metrics.totalServices}+</div>
              <p className="text-xs text-muted-foreground">Available at launch</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Data Centers</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{metrics.datacenters}</div>
              <p className="text-xs text-muted-foreground">UAE locations</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Compliance</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{metrics.complianceCertifications}</div>
              <p className="text-xs text-muted-foreground">Certifications</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Team Members</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{metrics.teamMembers}</div>
              <p className="text-xs text-muted-foreground">Across all phases</p>
            </CardContent>
          </Card>

          {/* EXAMPLE 9: New metrics cards */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Budget Used</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-600">{metrics.budgetUtilization}%</div>
              <p className="text-xs text-muted-foreground">Of allocated budget</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Risk Score</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{metrics.riskScore}</div>
              <p className="text-xs text-muted-foreground">Low risk profile</p>
            </CardContent>
          </Card>
        </div>

        {/* Rest of the component remains the same but with updated data */}
        {/* ... (timeline, tabs, etc.) ... */}
        
        {/* EXAMPLE 10: New status indicator */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Rocket className="h-5 w-5" />
              <span>Current Status: Data Center Readiness Phase</span>
            </CardTitle>
            <CardDescription>
              Infrastructure setup is 40% complete. Network configuration in progress.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <Progress value={40} className="h-3" />
              </div>
              <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Timeline and other components would follow with the updated data */}
      </main>
    </div>
  )
}

export default AppWithModifications

