import React from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Upload, Image, FileText, Eye, Save } from 'lucide-react'
import { toast } from 'sonner'

const BrandingTab = ({ settings, handleSettingChange, onSave }) => {
  const handleLogoUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        handleSettingChange('branding', 'logoUrl', e.target.result)
        toast.success('Logo uploaded successfully!')
      }
      reader.readAsDataURL(file)
    }
  }

  const handleFaviconUpload = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        handleSettingChange('branding', 'faviconUrl', e.target.result)
        toast.success('Favicon uploaded successfully!')
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Brand Identity</CardTitle>
        <CardDescription>Customize your organization's branding and identity</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <Label>Company Name</Label>
              <Input
                value={settings.branding.companyName}
                onChange={(e) => handleSettingChange('branding', 'companyName', e.target.value)}
                placeholder="e& enterprise"
                className="mt-1"
              />
            </div>
            
            <div>
              <Label>Header Title</Label>
              <Input
                value={settings.branding.headerTitle}
                onChange={(e) => handleSettingChange('branding', 'headerTitle', e.target.value)}
                placeholder="OneCloud Launch Tracker"
                className="mt-1"
              />
            </div>
            
            <div>
              <Label>Footer Text</Label>
              <Input
                value={settings.branding.footerText}
                onChange={(e) => handleSettingChange('branding', 'footerText', e.target.value)}
                placeholder="Powered by e& enterprise"
                className="mt-1"
              />
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <Label>Company Logo</Label>
              <div className="mt-1 space-y-2">
                {settings.branding.logoUrl && (
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <img 
                      src={settings.branding.logoUrl} 
                      alt="Company Logo" 
                      className="max-h-16 max-w-full object-contain"
                    />
                  </div>
                )}
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('logo-upload').click()}
                    className="flex items-center space-x-2"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload Logo</span>
                  </Button>
                  <input
                    id="logo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </div>
              </div>
            </div>
            
            <div>
              <Label>Favicon</Label>
              <div className="mt-1 space-y-2">
                {settings.branding.faviconUrl && (
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <img 
                      src={settings.branding.faviconUrl} 
                      alt="Favicon" 
                      className="w-8 h-8 object-contain"
                    />
                  </div>
                )}
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('favicon-upload').click()}
                    className="flex items-center space-x-2"
                  >
                    <Image className="w-4 h-4" />
                    <span>Upload Favicon</span>
                  </Button>
                  <input
                    id="favicon-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFaviconUpload}
                    className="hidden"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label>Custom Branding</Label>
              <p className="text-sm text-gray-500">Enable custom branding throughout the application</p>
            </div>
            <Switch
              checked={settings.branding.customBranding}
              onCheckedChange={(checked) => handleSettingChange('branding', 'customBranding', checked)}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <Label>Show "Powered By"</Label>
              <p className="text-sm text-gray-500">Display attribution in the footer</p>
            </div>
            <Switch
              checked={settings.branding.showPoweredBy}
              onCheckedChange={(checked) => handleSettingChange('branding', 'showPoweredBy', checked)}
            />
          </div>
        </div>
        
        <div className="pt-4 border-t">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Brand Preview</h4>
              <p className="text-sm text-gray-500">Preview how your branding will appear</p>
            </div>
            <Button onClick={onSave} className="flex items-center space-x-2">
              <Save className="w-4 h-4" />
              <span>Apply Branding</span>
            </Button>
          </div>
          
          <div className="mt-4 p-4 border rounded-lg bg-gray-50">
            <div className="flex items-center space-x-3 mb-2">
              {settings.branding.logoUrl && (
                <img 
                  src={settings.branding.logoUrl} 
                  alt="Logo Preview" 
                  className="h-8 object-contain"
                />
              )}
              <h3 className="text-lg font-semibold">{settings.branding.headerTitle}</h3>
            </div>
            <p className="text-sm text-gray-600">{settings.branding.companyName}</p>
            {settings.branding.showPoweredBy && (
              <p className="text-xs text-gray-500 mt-2">{settings.branding.footerText}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default BrandingTab

