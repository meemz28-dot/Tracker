import { useState, useEffect } from 'react'
import { Search, Filter, X, Save, Clock, User, Calendar, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'

const SearchAndFilter = ({ phases, onFilterChange, isEditMode }) => {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeFilters, setActiveFilters] = useState({})
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [savedFilters, setSavedFilters] = useState({})
  const [searchHistory, setSearchHistory] = useState([])
  const [searchResults, setSearchResults] = useState([])

  useEffect(() => {
    // Load saved filters and search history from localStorage
    const saved = JSON.parse(localStorage.getItem('savedFilters') || '{}')
    const history = JSON.parse(localStorage.getItem('searchHistory') || '[]')
    setSavedFilters(saved)
    setSearchHistory(history)
  }, [])

  useEffect(() => {
    // Perform search and filtering
    const results = performSearch(searchQuery, activeFilters)
    setSearchResults(results)
    onFilterChange(results)
  }, [searchQuery, activeFilters, phases])

  const performSearch = (query, filters) => {
    let results = []

    // Search through all data
    phases.forEach(phase => {
      // Search phase data
      if (matchesSearch(phase, query) && matchesFilters(phase, filters)) {
        results.push({
          type: 'phase',
          id: phase.id,
          title: phase.name,
          description: phase.description,
          status: phase.status,
          progress: phase.progress,
          responsiblePerson: phase.responsiblePerson,
          responsibleFunction: phase.responsibleFunction,
          startDate: phase.startDate,
          endDate: phase.endDate,
          parent: null
        })
      }

      // Search tasks within phases
      phase.tasks?.forEach(task => {
        if (matchesSearch(task, query) && matchesFilters(task, filters)) {
          results.push({
            type: 'task',
            id: `${phase.id}-${task.name}`,
            title: task.name,
            description: `Task in ${phase.name}`,
            status: task.status,
            responsiblePerson: task.responsiblePerson,
            responsibleFunction: task.responsibleFunction,
            parent: phase.name
          })
        }
      })
    })

    return results
  }

  const matchesSearch = (item, query) => {
    if (!query) return true
    
    const searchFields = [
      item.name,
      item.title,
      item.description,
      item.responsiblePerson,
      item.responsibleFunction
    ].filter(Boolean)

    return searchFields.some(field => 
      field.toLowerCase().includes(query.toLowerCase())
    )
  }

  const matchesFilters = (item, filters) => {
    return Object.entries(filters).every(([key, value]) => {
      if (!value || value === 'all') return true
      
      switch (key) {
        case 'status':
          return item.status === value
        case 'person':
          return item.responsiblePerson === value
        case 'dateRange':
          if (item.startDate && item.endDate) {
            const start = new Date(item.startDate)
            const end = new Date(item.endDate)
            const now = new Date()
            
            switch (value) {
              case 'overdue':
                return end < now && item.status !== 'completed'
              case 'thisWeek':
                const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000)
                return end <= weekFromNow && end >= now
              case 'thisMonth':
                return end.getMonth() === now.getMonth() && end.getFullYear() === now.getFullYear()
              default:
                return true
            }
          }
          return true
        default:
          return true
      }
    })
  }

  const handleSearch = (query) => {
    setSearchQuery(query)
    
    // Add to search history
    if (query && !searchHistory.includes(query)) {
      const newHistory = [query, ...searchHistory.slice(0, 9)] // Keep last 10 searches
      setSearchHistory(newHistory)
      localStorage.setItem('searchHistory', JSON.stringify(newHistory))
    }
  }

  const applyFilter = (filterType, value) => {
    const newFilters = { ...activeFilters, [filterType]: value }
    setActiveFilters(newFilters)
  }

  const removeFilter = (filterType) => {
    const newFilters = { ...activeFilters }
    delete newFilters[filterType]
    setActiveFilters(newFilters)
  }

  const clearAllFilters = () => {
    setActiveFilters({})
    setSearchQuery('')
  }

  const saveCurrentFilter = () => {
    const filterName = prompt('Enter a name for this filter:')
    if (filterName) {
      const newSavedFilters = {
        ...savedFilters,
        [filterName]: { query: searchQuery, filters: activeFilters }
      }
      setSavedFilters(newSavedFilters)
      localStorage.setItem('savedFilters', JSON.stringify(newSavedFilters))
    }
  }

  const loadSavedFilter = (filterName) => {
    const filter = savedFilters[filterName]
    if (filter) {
      setSearchQuery(filter.query || '')
      setActiveFilters(filter.filters || {})
    }
  }

  const deleteSavedFilter = (filterName) => {
    const newSavedFilters = { ...savedFilters }
    delete newSavedFilters[filterName]
    setSavedFilters(newSavedFilters)
    localStorage.setItem('savedFilters', JSON.stringify(newSavedFilters))
  }

  // Get unique values for filter options
  const allPeople = [...new Set(phases.flatMap(p => [
    p.responsiblePerson,
    ...(p.tasks?.map(t => t.responsiblePerson) || [])
  ]).filter(Boolean))]

  const statusOptions = ['completed', 'in-progress', 'pending', 'blocked', 'on-hold']

  return (
    <div className="space-y-4">
      {/* Main Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search phases, tasks, people, or descriptions..."
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10 pr-10"
        />
        {searchQuery && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleSearch('')}
            className="absolute right-2 top-1/2 transform -translate-y-1/2"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Quick Filter Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button
          variant={activeFilters.status === 'in-progress' ? 'default' : 'outline'}
          size="sm"
          onClick={() => applyFilter('status', activeFilters.status === 'in-progress' ? null : 'in-progress')}
        >
          In Progress
        </Button>
        <Button
          variant={activeFilters.status === 'completed' ? 'default' : 'outline'}
          size="sm"
          onClick={() => applyFilter('status', activeFilters.status === 'completed' ? null : 'completed')}
        >
          Completed
        </Button>
        <Button
          variant={activeFilters.dateRange === 'overdue' ? 'default' : 'outline'}
          size="sm"
          onClick={() => applyFilter('dateRange', activeFilters.dateRange === 'overdue' ? null : 'overdue')}
        >
          Overdue
        </Button>
        <Button
          variant={activeFilters.dateRange === 'thisWeek' ? 'default' : 'outline'}
          size="sm"
          onClick={() => applyFilter('dateRange', activeFilters.dateRange === 'thisWeek' ? null : 'thisWeek')}
        >
          This Week
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
        >
          <Filter className="h-4 w-4 mr-2" />
          Advanced
        </Button>
      </div>

      {/* Active Filters Display */}
      {Object.keys(activeFilters).length > 0 && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-gray-600">Active filters:</span>
          {Object.entries(activeFilters).map(([key, value]) => (
            <Badge key={key} variant="secondary" className="flex items-center gap-1">
              {key}: {value}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeFilter(key)}
                className="h-4 w-4 p-0 ml-1"
              >
                <X className="h-3 w-3" />
              </Button>
            </Badge>
          ))}
          <Button variant="ghost" size="sm" onClick={clearAllFilters}>
            Clear all
          </Button>
          {isEditMode && (
            <Button variant="outline" size="sm" onClick={saveCurrentFilter}>
              <Save className="h-4 w-4 mr-2" />
              Save Filter
            </Button>
          )}
        </div>
      )}

      {/* Advanced Filters Panel */}
      {showAdvancedFilters && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Advanced Filters</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Status Filter */}
              <div>
                <label className="block text-sm font-medium mb-2">Status</label>
                <select
                  value={activeFilters.status || 'all'}
                  onChange={(e) => applyFilter('status', e.target.value === 'all' ? null : e.target.value)}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="all">All Statuses</option>
                  {statusOptions.map(status => (
                    <option key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
                    </option>
                  ))}
                </select>
              </div>

              {/* Person Filter */}
              <div>
                <label className="block text-sm font-medium mb-2">Responsible Person</label>
                <select
                  value={activeFilters.person || 'all'}
                  onChange={(e) => applyFilter('person', e.target.value === 'all' ? null : e.target.value)}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="all">All People</option>
                  {allPeople.map(person => (
                    <option key={person} value={person}>{person}</option>
                  ))}
                </select>
              </div>

              {/* Date Range Filter */}
              <div>
                <label className="block text-sm font-medium mb-2">Date Range</label>
                <select
                  value={activeFilters.dateRange || 'all'}
                  onChange={(e) => applyFilter('dateRange', e.target.value === 'all' ? null : e.target.value)}
                  className="w-full border rounded px-3 py-2"
                >
                  <option value="all">All Dates</option>
                  <option value="overdue">Overdue</option>
                  <option value="thisWeek">This Week</option>
                  <option value="thisMonth">This Month</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Saved Filters & Search History */}
      {isEditMode && (Object.keys(savedFilters).length > 0 || searchHistory.length > 0) && (
        <Tabs defaultValue="saved" className="w-full">
          <TabsList>
            <TabsTrigger value="saved">Saved Filters</TabsTrigger>
            <TabsTrigger value="history">Search History</TabsTrigger>
          </TabsList>
          
          <TabsContent value="saved">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Saved Filters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(savedFilters).map(([name, filter]) => (
                    <div key={name} className="flex items-center justify-between p-2 border rounded">
                      <div>
                        <span className="font-medium">{name}</span>
                        {filter.query && (
                          <span className="text-sm text-gray-600 ml-2">"{filter.query}"</span>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => loadSavedFilter(name)}>
                          Apply
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => deleteSavedFilter(name)}>
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Searches</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {searchHistory.map((query, index) => (
                    <div key={index} className="flex items-center justify-between p-2 border rounded">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span>{query}</span>
                      </div>
                      <Button size="sm" variant="outline" onClick={() => handleSearch(query)}>
                        Search Again
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Search Results Summary */}
      {searchQuery && (
        <div className="text-sm text-gray-600">
          Found {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} 
          {searchQuery && ` for "${searchQuery}"`}
        </div>
      )}
    </div>
  )
}

export default SearchAndFilter

