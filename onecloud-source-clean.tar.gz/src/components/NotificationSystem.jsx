import { useState, useEffect } from 'react'
import { Bell, X, CheckCircle, AlertTriangle, Info, Clock } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'

const NotificationSystem = ({ phases, isEditMode }) => {
  const [notifications, setNotifications] = useState([])
  const [showNotifications, setShowNotifications] = useState(false)
  const [notificationPermission, setNotificationPermission] = useState('default')

  useEffect(() => {
    // Request notification permission
    if ('Notification' in window) {
      Notification.requestPermission().then(permission => {
        setNotificationPermission(permission)
      })
    }
  }, [])

  useEffect(() => {
    // Generate smart notifications based on project data
    const newNotifications = generateSmartNotifications(phases)
    setNotifications(newNotifications)
  }, [phases])

  const generateSmartNotifications = (phases) => {
    const notifications = []
    const now = new Date()

    phases.forEach(phase => {
      const endDate = new Date(phase.endDate)
      const daysUntilDeadline = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24))

      // Overdue notifications
      if (daysUntilDeadline < 0 && phase.status !== 'completed') {
        notifications.push({
          id: `overdue-${phase.id}`,
          type: 'error',
          title: 'Phase Overdue',
          message: `${phase.name} is ${Math.abs(daysUntilDeadline)} days overdue`,
          timestamp: now,
          priority: 'high',
          phase: phase.name
        })
      }

      // Upcoming deadline notifications
      if (daysUntilDeadline <= 3 && daysUntilDeadline > 0 && phase.status !== 'completed') {
        notifications.push({
          id: `deadline-${phase.id}`,
          type: 'warning',
          title: 'Deadline Approaching',
          message: `${phase.name} due in ${daysUntilDeadline} day${daysUntilDeadline > 1 ? 's' : ''}`,
          timestamp: now,
          priority: 'medium',
          phase: phase.name
        })
      }

      // Progress notifications
      if (phase.progress < 50 && phase.status === 'in-progress') {
        const daysSinceStart = Math.ceil((now - new Date(phase.startDate)) / (1000 * 60 * 60 * 24))
        if (daysSinceStart > 7) {
          notifications.push({
            id: `progress-${phase.id}`,
            type: 'warning',
            title: 'Low Progress Alert',
            message: `${phase.name} is only ${phase.progress}% complete after ${daysSinceStart} days`,
            timestamp: now,
            priority: 'medium',
            phase: phase.name
          })
        }
      }

      // Completion celebrations
      if (phase.status === 'completed' && phase.progress === 100) {
        notifications.push({
          id: `completed-${phase.id}`,
          type: 'success',
          title: 'Phase Completed!',
          message: `🎉 ${phase.name} has been successfully completed`,
          timestamp: now,
          priority: 'low',
          phase: phase.name
        })
      }

      // Task-level notifications
      phase.tasks?.forEach(task => {
        if (task.status === 'completed') {
          notifications.push({
            id: `task-completed-${phase.id}-${task.name}`,
            type: 'info',
            title: 'Task Completed',
            message: `${task.name} completed by ${task.responsiblePerson}`,
            timestamp: now,
            priority: 'low',
            phase: phase.name
          })
        }
      })
    })

    // Sort by priority and timestamp
    return notifications.sort((a, b) => {
      const priorityOrder = { high: 3, medium: 2, low: 1 }
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[b.priority] - priorityOrder[a.priority]
      }
      return new Date(b.timestamp) - new Date(a.timestamp)
    }).slice(0, 10) // Limit to 10 most important notifications
  }

  const sendBrowserNotification = (notification) => {
    if (notificationPermission === 'granted') {
      new Notification(notification.title, {
        body: notification.message,
        icon: '/e_enterprise_logo.jpeg',
        badge: '/notification-badge.png',
        tag: notification.id,
        requireInteraction: notification.priority === 'high'
      })
    }
  }

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-500" />
      case 'info': return <Info className="h-4 w-4 text-blue-500" />
      default: return <Bell className="h-4 w-4" />
    }
  }

  const getNotificationColor = (type) => {
    switch (type) {
      case 'success': return 'border-l-green-500 bg-green-50'
      case 'warning': return 'border-l-yellow-500 bg-yellow-50'
      case 'error': return 'border-l-red-500 bg-red-50'
      case 'info': return 'border-l-blue-500 bg-blue-50'
      default: return 'border-l-gray-500 bg-gray-50'
    }
  }

  const dismissNotification = (notificationId) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId))
  }

  const markAllAsRead = () => {
    setNotifications([])
  }

  const unreadCount = notifications.length

  return (
    <div className="relative">
      {/* Notification Bell */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setShowNotifications(!showNotifications)}
        className="relative"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <Badge 
            variant="destructive" 
            className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </Badge>
        )}
      </Button>

      {/* Notification Panel */}
      {showNotifications && (
        <Card className="absolute right-0 top-12 w-96 max-h-96 overflow-y-auto z-50 shadow-lg">
          <CardContent className="p-0">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-semibold">Notifications</h3>
              <div className="flex gap-2">
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                    Mark all read
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => setShowNotifications(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {notifications.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No new notifications</p>
              </div>
            ) : (
              <div className="divide-y">
                {notifications.map(notification => (
                  <div
                    key={notification.id}
                    className={`p-4 border-l-4 ${getNotificationColor(notification.type)} hover:bg-gray-50 transition-colors`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3 flex-1">
                        {getNotificationIcon(notification.type)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium text-sm">{notification.title}</h4>
                            <Badge variant="outline" className="text-xs">
                              {notification.phase}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
                          <div className="flex items-center gap-2 mt-2 text-xs text-gray-500">
                            <Clock className="h-3 w-3" />
                            {new Date(notification.timestamp).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => dismissNotification(notification.id)}
                        className="ml-2"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Notification Settings (for edit mode) */}
      {isEditMode && (
        <div className="mt-4 p-4 border rounded-lg bg-gray-50">
          <h4 className="font-medium mb-2">Notification Settings</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span>Browser Notifications</span>
              <Badge variant={notificationPermission === 'granted' ? 'default' : 'secondary'}>
                {notificationPermission}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span>Active Notifications</span>
              <Badge variant="outline">{unreadCount}</Badge>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const testNotification = {
                  title: 'Test Notification',
                  message: 'This is a test notification from OneCloud Tracker',
                  type: 'info'
                }
                sendBrowserNotification(testNotification)
              }}
              disabled={notificationPermission !== 'granted'}
            >
              Send Test Notification
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

export default NotificationSystem

