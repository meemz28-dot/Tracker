import { useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area } from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Download, Maximize2, Filter, Calendar, TrendingUp, BarChart3 } from 'lucide-react'

const InteractiveCharts = ({ phases, overallProgress }) => {
  const [selectedChart, setSelectedChart] = useState(null)
  const [timeRange, setTimeRange] = useState('6months')
  const [chartType, setChartType] = useState('line')

  // Generate progress tracking data
  const progressData = [
    { month: 'Jan', planned: 20, actual: 15, target: 25 },
    { month: 'Feb', planned: 35, actual: 30, target: 40 },
    { month: 'Mar', planned: 50, actual: 45, target: 55 },
    { month: 'Apr', planned: 65, actual: 60, target: 70 },
    { month: 'May', planned: 80, actual: 75, target: 85 },
    { month: 'Jun', planned: 95, actual: 85, target: 100 },
    { month: 'Jul', planned: 100, actual: 100, target: 100 }
  ]

  // Generate phase distribution data
  const phaseData = phases.map(phase => ({
    name: phase.name.split(' ')[0], // Shortened name
    progress: phase.progress,
    status: phase.status,
    tasks: phase.tasks?.length || 0,
    daysRemaining: Math.ceil((new Date(phase.endDate) - new Date()) / (1000 * 60 * 60 * 24))
  }))

  // Generate velocity data
  const velocityData = [
    { week: 'Week 1', tasksCompleted: 8, velocity: 2.0, burndown: 92 },
    { week: 'Week 2', tasksCompleted: 12, velocity: 2.4, burndown: 80 },
    { week: 'Week 3', tasksCompleted: 10, velocity: 2.2, burndown: 70 },
    { week: 'Week 4', tasksCompleted: 15, velocity: 2.8, burndown: 55 },
    { week: 'Week 5', tasksCompleted: 11, velocity: 2.3, burndown: 44 },
    { week: 'Week 6', tasksCompleted: 13, velocity: 2.6, burndown: 31 }
  ]

  // Generate resource utilization data
  const resourceData = [
    { department: 'Engineering', allocated: 18, utilized: 16, capacity: 20 },
    { department: 'Operations', allocated: 12, utilized: 11, capacity: 15 },
    { department: 'Security', allocated: 8, utilized: 7, capacity: 10 },
    { department: 'Legal', allocated: 4, utilized: 4, capacity: 5 },
    { department: 'PM', allocated: 3, utilized: 3, capacity: 4 }
  ]

  const COLORS = ['#E30613', '#1B365D', '#FFB81C', '#4CAF50', '#9C27B0', '#FF9800']

  const CustomTooltip = ({ active, payload, label, onDrillDown }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border rounded-lg shadow-lg">
          <p className="font-medium">{label}</p>
          {payload.map((entry, index) => (
            <div key={index} className="flex items-center gap-2 mt-1">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-sm">
                {entry.name}: {entry.value}
                {entry.name.includes('progress') || entry.name.includes('Progress') ? '%' : ''}
              </span>
            </div>
          ))}
          {onDrillDown && (
            <Button 
              size="sm" 
              variant="outline" 
              className="mt-2 text-xs"
              onClick={() => onDrillDown(label, payload)}
            >
              View Details
            </Button>
          )}
        </div>
      )
    }
    return null
  }

  const handleChartClick = (data, chartName) => {
    setSelectedChart({
      name: chartName,
      data: data,
      timestamp: new Date().toLocaleString()
    })
  }

  const exportChart = (chartName) => {
    // In a real implementation, this would export the chart as PNG/PDF
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    
    // Create a simple export notification
    alert(`Exporting ${chartName} chart... (Feature would export as PNG/PDF in production)`)
  }

  const DrillDownModal = ({ chart, onClose }) => {
    if (!chart) return null

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <Card className="w-3/4 max-w-4xl max-h-3/4 overflow-auto">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>{chart.name} - Detailed View</CardTitle>
                <CardDescription>Exported on {chart.timestamp}</CardDescription>
              </div>
              <Button variant="ghost" onClick={onClose}>×</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium mb-2">Data Summary</h4>
                  <div className="text-sm space-y-1">
                    {chart.data.map((item, index) => (
                      <div key={index} className="flex justify-between">
                        <span>{item.name || item.dataKey}:</span>
                        <span className="font-medium">{item.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Insights</h4>
                  <div className="text-sm space-y-1 text-gray-600">
                    <p>• Trend analysis shows positive momentum</p>
                    <p>• Performance is within expected parameters</p>
                    <p>• Recommend continued monitoring</p>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={() => exportChart(chart.name)}>
                  <Download className="h-4 w-4 mr-2" />
                  Export PNG
                </Button>
                <Button size="sm" variant="outline" onClick={() => exportChart(chart.name)}>
                  <Download className="h-4 w-4 mr-2" />
                  Export PDF
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Chart Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <select 
              value={timeRange} 
              onChange={(e) => setTimeRange(e.target.value)}
              className="border rounded px-2 py-1 text-sm"
            >
              <option value="3months">Last 3 months</option>
              <option value="6months">Last 6 months</option>
              <option value="1year">Last year</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            <select 
              value={chartType} 
              onChange={(e) => setChartType(e.target.value)}
              className="border rounded px-2 py-1 text-sm"
            >
              <option value="line">Line Chart</option>
              <option value="bar">Bar Chart</option>
              <option value="area">Area Chart</option>
            </select>
          </div>
        </div>
        <Badge variant="outline" className="flex items-center gap-1">
          <TrendingUp className="h-3 w-3" />
          Interactive Mode
        </Badge>
      </div>

      <Tabs defaultValue="progress" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
          <TabsTrigger value="phases">Phase Analysis</TabsTrigger>
          <TabsTrigger value="velocity">Team Velocity</TabsTrigger>
          <TabsTrigger value="resources">Resource Utilization</TabsTrigger>
        </TabsList>

        <TabsContent value="progress" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Progress vs Timeline</CardTitle>
                  <CardDescription>Planned vs Actual Progress Over Time</CardDescription>
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => exportChart('Progress Timeline')}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                {chartType === 'line' && (
                  <LineChart data={progressData} onClick={(data) => handleChartClick(data, 'Progress Timeline')}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip content={<CustomTooltip onDrillDown={handleChartClick} />} />
                    <Legend />
                    <Line type="monotone" dataKey="planned" stroke="#1B365D" strokeWidth={2} name="Planned Progress" />
                    <Line type="monotone" dataKey="actual" stroke="#E30613" strokeWidth={2} name="Actual Progress" />
                    <Line type="monotone" dataKey="target" stroke="#FFB81C" strokeWidth={2} strokeDasharray="5 5" name="Target" />
                  </LineChart>
                )}
                {chartType === 'bar' && (
                  <BarChart data={progressData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="planned" fill="#1B365D" name="Planned Progress" />
                    <Bar dataKey="actual" fill="#E30613" name="Actual Progress" />
                  </BarChart>
                )}
                {chartType === 'area' && (
                  <AreaChart data={progressData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Area type="monotone" dataKey="planned" stackId="1" stroke="#1B365D" fill="#1B365D" fillOpacity={0.6} name="Planned Progress" />
                    <Area type="monotone" dataKey="actual" stackId="2" stroke="#E30613" fill="#E30613" fillOpacity={0.6} name="Actual Progress" />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="phases" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Phase Progress Distribution</CardTitle>
                <CardDescription>Current status across all phases</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={phaseData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="progress" fill="#E30613" name="Progress %" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Phase Status Overview</CardTitle>
                <CardDescription>Distribution by completion status</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Completed', value: phases.filter(p => p.status === 'completed').length, color: '#4CAF50' },
                        { name: 'In Progress', value: phases.filter(p => p.status === 'in-progress').length, color: '#FFB81C' },
                        { name: 'Pending', value: phases.filter(p => p.status === 'pending').length, color: '#9E9E9E' }
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {phases.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="velocity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Team Velocity & Burndown</CardTitle>
              <CardDescription>Task completion rate and remaining work</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={velocityData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar yAxisId="left" dataKey="tasksCompleted" fill="#E30613" name="Tasks Completed" />
                  <Line yAxisId="right" type="monotone" dataKey="burndown" stroke="#1B365D" strokeWidth={2} name="Remaining Work" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Resource Utilization</CardTitle>
              <CardDescription>Team capacity and allocation across departments</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={resourceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="department" />
                  <YAxis />
                  <Tooltip content={<CustomTooltip />} />
                  <Legend />
                  <Bar dataKey="capacity" fill="#E5E7EB" name="Total Capacity" />
                  <Bar dataKey="allocated" fill="#1B365D" name="Allocated" />
                  <Bar dataKey="utilized" fill="#E30613" name="Utilized" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Drill-down Modal */}
      <DrillDownModal 
        chart={selectedChart} 
        onClose={() => setSelectedChart(null)} 
      />
    </div>
  )
}

export default InteractiveCharts

