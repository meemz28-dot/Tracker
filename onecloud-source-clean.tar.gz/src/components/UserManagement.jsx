import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Users, UserPlus, Shield, Edit, Trash2, Eye, Settings } from 'lucide-react'

const UserManagement = ({ currentUser, users, setUsers, onUserUpdate }) => {
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [editingUser, setEditingUser] = useState(null)
  const [newUser, setNewUser] = useState({
    id: '',
    name: '',
    email: '',
    role: 'viewer',
    pin: '',
    isActive: true,
    createdAt: new Date().toISOString(),
    lastLogin: null
  })

  const roles = [
    { value: 'viewer', label: 'Viewer', description: 'Read-only access to dashboard', icon: Eye, color: 'bg-gray-100 text-gray-800' },
    { value: 'editor', label: 'Editor', description: 'Can modify project data and tasks', icon: Edit, color: 'bg-blue-100 text-blue-800' },
    { value: 'admin', label: 'Admin', description: 'Full access including user management', icon: Shield, color: 'bg-red-100 text-red-800' }
  ]

  const permissions = {
    viewer: ['read_dashboard', 'view_reports'],
    editor: ['read_dashboard', 'view_reports', 'edit_tasks', 'edit_phases', 'create_reports'],
    admin: ['read_dashboard', 'view_reports', 'edit_tasks', 'edit_phases', 'create_reports', 'manage_users', 'admin_settings', 'system_config']
  }

  const generateUserId = () => {
    return 'user_' + Math.random().toString(36).substr(2, 9)
  }

  const generateRandomPIN = () => {
    return Math.floor(1000 + Math.random() * 9000).toString()
  }

  const handleAddUser = () => {
    if (!newUser.name || !newUser.email) {
      alert('Please fill in all required fields')
      return
    }

    const userToAdd = {
      ...newUser,
      id: generateUserId(),
      pin: newUser.pin || generateRandomPIN(),
      createdAt: new Date().toISOString()
    }

    setUsers(prev => [...prev, userToAdd])
    setNewUser({
      id: '',
      name: '',
      email: '',
      role: 'viewer',
      pin: '',
      isActive: true,
      createdAt: new Date().toISOString(),
      lastLogin: null
    })
    setIsAddUserOpen(false)
    onUserUpdate && onUserUpdate()
  }

  const handleEditUser = (user) => {
    setEditingUser({ ...user })
  }

  const handleUpdateUser = () => {
    setUsers(prev => prev.map(user => 
      user.id === editingUser.id ? editingUser : user
    ))
    setEditingUser(null)
    onUserUpdate && onUserUpdate()
  }

  const handleDeleteUser = (userId) => {
    if (userId === currentUser.id) {
      alert('You cannot delete your own account')
      return
    }
    
    if (confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
      setUsers(prev => prev.filter(user => user.id !== userId))
      onUserUpdate && onUserUpdate()
    }
  }

  const toggleUserStatus = (userId) => {
    setUsers(prev => prev.map(user => 
      user.id === userId ? { ...user, isActive: !user.isActive } : user
    ))
    onUserUpdate && onUserUpdate()
  }

  const getRoleInfo = (roleValue) => {
    return roles.find(role => role.value === roleValue) || roles[0]
  }

  const hasPermission = (user, permission) => {
    return permissions[user.role]?.includes(permission) || false
  }

  if (currentUser.role !== 'admin') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5" />
            <span>User Management</span>
          </CardTitle>
          <CardDescription>
            Access restricted to administrators only
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">
            You need administrator privileges to access user management features.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5" />
                <span>User Management</span>
              </CardTitle>
              <CardDescription>
                Manage user accounts, roles, and permissions
              </CardDescription>
            </div>
            <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
              <DialogTrigger asChild>
                <Button className="flex items-center space-x-2">
                  <UserPlus className="w-4 h-4" />
                  <span>Add User</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New User</DialogTitle>
                  <DialogDescription>
                    Create a new user account with appropriate role and permissions
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Name *</label>
                    <Input
                      value={newUser.name}
                      onChange={(e) => setNewUser(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Email *</label>
                    <Input
                      type="email"
                      value={newUser.email}
                      onChange={(e) => setNewUser(prev => ({ ...prev, email: e.target.value }))}
                      placeholder="Enter email address"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Role</label>
                    <Select value={newUser.role} onValueChange={(value) => setNewUser(prev => ({ ...prev, role: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {roles.map(role => (
                          <SelectItem key={role.value} value={role.value}>
                            <div className="flex items-center space-x-2">
                              <role.icon className="w-4 h-4" />
                              <div>
                                <div className="font-medium">{role.label}</div>
                                <div className="text-xs text-gray-500">{role.description}</div>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">PIN (optional)</label>
                    <Input
                      value={newUser.pin}
                      onChange={(e) => setNewUser(prev => ({ ...prev, pin: e.target.value }))}
                      placeholder="Leave empty to auto-generate"
                      maxLength={4}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      If left empty, a random 4-digit PIN will be generated
                    </p>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsAddUserOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddUser}>
                      Add User
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map(user => {
              const roleInfo = getRoleInfo(user.role)
              const RoleIcon = roleInfo.icon
              
              return (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <Users className="w-5 h-5 text-gray-600" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{user.name}</span>
                        {user.id === currentUser.id && (
                          <Badge variant="outline" className="text-xs">You</Badge>
                        )}
                        {!user.isActive && (
                          <Badge variant="destructive" className="text-xs">Inactive</Badge>
                        )}
                      </div>
                      <div className="text-sm text-gray-600">{user.email}</div>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge className={roleInfo.color}>
                          <RoleIcon className="w-3 h-3 mr-1" />
                          {roleInfo.label}
                        </Badge>
                        <span className="text-xs text-gray-500">PIN: {user.pin}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => toggleUserStatus(user.id)}
                      disabled={user.id === currentUser.id}
                    >
                      {user.isActive ? 'Deactivate' : 'Activate'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEditUser(user)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteUser(user.id)}
                      disabled={user.id === currentUser.id}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Role Permissions Reference */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Role Permissions</span>
          </CardTitle>
          <CardDescription>
            Overview of permissions for each user role
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {roles.map(role => {
              const RoleIcon = role.icon
              const rolePermissions = permissions[role.value] || []
              
              return (
                <div key={role.value} className="border rounded-lg p-4">
                  <div className="flex items-center space-x-2 mb-3">
                    <RoleIcon className="w-5 h-5" />
                    <span className="font-medium">{role.label}</span>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{role.description}</p>
                  <div className="space-y-1">
                    <div className="text-xs font-medium text-gray-500 uppercase">Permissions:</div>
                    {rolePermissions.map(permission => (
                      <div key={permission} className="text-xs text-gray-600">
                        • {permission.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* Edit User Dialog */}
      {editingUser && (
        <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit User</DialogTitle>
              <DialogDescription>
                Modify user information and permissions
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <Input
                  value={editingUser.name}
                  onChange={(e) => setEditingUser(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <Input
                  type="email"
                  value={editingUser.email}
                  onChange={(e) => setEditingUser(prev => ({ ...prev, email: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Role</label>
                <Select value={editingUser.role} onValueChange={(value) => setEditingUser(prev => ({ ...prev, role: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map(role => (
                      <SelectItem key={role.value} value={role.value}>
                        <div className="flex items-center space-x-2">
                          <role.icon className="w-4 h-4" />
                          <div>
                            <div className="font-medium">{role.label}</div>
                            <div className="text-xs text-gray-500">{role.description}</div>
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">PIN</label>
                <Input
                  value={editingUser.pin}
                  onChange={(e) => setEditingUser(prev => ({ ...prev, pin: e.target.value }))}
                  maxLength={4}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setEditingUser(null)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdateUser}>
                  Update User
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

export default UserManagement

