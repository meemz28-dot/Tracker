import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { 
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area,
  RadialBarChart,
  RadialBar,
  ScatterChart,
  Scatter,
  ComposedChart
} from 'recharts'
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Users, 
  Clock, 
  Target, 
  AlertTriangle, 
  CheckCircle, 
  Calendar, 
  BarChart3, 
  PieChart as PieChartIcon, 
  LineChart as LineChartIcon,
  Settings,
  Filter,
  Download,
  RefreshCw,
  Maximize,
  Minimize,
  Eye,
  EyeOff,
  Grid,
  List,
  Calendar as CalendarIcon,
  Zap,
  Shield,
  Server,
  Database,
  Globe,
  Cpu,
  HardDrive,
  Wifi,
  Battery,
  Thermometer,
  Gauge,
  Signal,
  Monitor,
  Smartphone,
  Tablet,
  Laptop
} from 'lucide-react'

const AdvancedDashboard = ({ 
  phases, 
  metrics, 
  currentUser, 
  isEditMode,
  adminSettings,
  onMetricUpdate 
}) => {
  const [dashboardLayout, setDashboardLayout] = useState('grid')
  const [selectedTimeRange, setSelectedTimeRange] = useState('7d')
  const [activeWidgets, setActiveWidgets] = useState({
    overview: true,
    progress: true,
    timeline: true,
    team: true,
    performance: true,
    risks: true,
    resources: true,
    analytics: true
  })
  const [chartTypes, setChartTypes] = useState({
    progress: 'bar',
    timeline: 'line',
    performance: 'area',
    resources: 'pie'
  })
  const [realTimeData, setRealTimeData] = useState({
    cpuUsage: 45,
    memoryUsage: 67,
    networkActivity: 23,
    activeConnections: 156,
    responseTime: 245,
    errorRate: 0.02
  })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [refreshInterval, setRefreshInterval] = useState(30)
  const [autoRefresh, setAutoRefresh] = useState(true)

  // Enhanced metrics calculation
  const [enhancedMetrics, setEnhancedMetrics] = useState({
    totalTasks: 0,
    completedTasks: 0,
    inProgressTasks: 0,
    overdueTasks: 0,
    upcomingDeadlines: 0,
    teamEfficiency: 0,
    budgetUtilization: 0,
    riskScore: 0,
    qualityScore: 0,
    customerSatisfaction: 0
  })

  // Time range options
  const timeRanges = [
    { value: '24h', label: 'Last 24 Hours' },
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 90 Days' },
    { value: '1y', label: 'Last Year' },
    { value: 'custom', label: 'Custom Range' }
  ]

  // Generate sample data for charts
  const generateProgressData = () => {
    return phases.map(phase => ({
      name: phase.name.substring(0, 15) + (phase.name.length > 15 ? '...' : ''),
      progress: phase.progress || 0,
      planned: Math.min(100, (phase.progress || 0) + Math.random() * 20),
      tasks: phase.tasks?.length || 0,
      completed: phase.tasks?.filter(t => t.status === 'completed').length || 0
    }))
  }

  const generateTimelineData = () => {
    const data = []
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - 30)

    for (let i = 0; i < 30; i++) {
      const date = new Date(startDate)
      date.setDate(date.getDate() + i)
      
      data.push({
        date: date.toISOString().split('T')[0],
        completed: Math.floor(Math.random() * 10),
        started: Math.floor(Math.random() * 8),
        planned: Math.floor(Math.random() * 12)
      })
    }
    return data
  }

  const generatePerformanceData = () => {
    return [
      { metric: 'Efficiency', value: 85, target: 90 },
      { metric: 'Quality', value: 92, target: 95 },
      { metric: 'Timeline', value: 78, target: 85 },
      { metric: 'Budget', value: 88, target: 90 },
      { metric: 'Satisfaction', value: 94, target: 95 }
    ]
  }

  const generateResourceData = () => {
    return [
      { name: 'Development', value: 35, color: '#8884d8' },
      { name: 'Testing', value: 25, color: '#82ca9d' },
      { name: 'Documentation', value: 15, color: '#ffc658' },
      { name: 'Management', value: 15, color: '#ff7300' },
      { name: 'Support', value: 10, color: '#00ff00' }
    ]
  }

  const generateRealTimeMetrics = () => {
    return [
      { name: 'CPU', value: realTimeData.cpuUsage, max: 100, color: '#8884d8' },
      { name: 'Memory', value: realTimeData.memoryUsage, max: 100, color: '#82ca9d' },
      { name: 'Network', value: realTimeData.networkActivity, max: 100, color: '#ffc658' },
      { name: 'Storage', value: 45, max: 100, color: '#ff7300' }
    ]
  }

  // Calculate enhanced metrics
  useEffect(() => {
    const calculateMetrics = () => {
      let totalTasks = 0
      let completedTasks = 0
      let inProgressTasks = 0
      let overdueTasks = 0

      phases.forEach(phase => {
        if (phase.tasks) {
          totalTasks += phase.tasks.length
          completedTasks += phase.tasks.filter(t => t.status === 'completed').length
          inProgressTasks += phase.tasks.filter(t => t.status === 'in-progress').length
          
          // Check for overdue tasks
          phase.tasks.forEach(task => {
            if (task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed') {
              overdueTasks++
            }
          })
        }
      })

      const teamEfficiency = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0
      const riskScore = Math.max(0, 100 - (overdueTasks * 10))

      setEnhancedMetrics({
        totalTasks,
        completedTasks,
        inProgressTasks,
        overdueTasks,
        upcomingDeadlines: Math.floor(Math.random() * 5) + 2,
        teamEfficiency,
        budgetUtilization: Math.floor(Math.random() * 20) + 75,
        riskScore,
        qualityScore: Math.floor(Math.random() * 10) + 85,
        customerSatisfaction: Math.floor(Math.random() * 5) + 90
      })
    }

    calculateMetrics()
  }, [phases])

  // Auto-refresh functionality
  useEffect(() => {
    if (autoRefresh && refreshInterval > 0) {
      const interval = setInterval(() => {
        setRealTimeData(prev => ({
          ...prev,
          cpuUsage: Math.max(0, Math.min(100, prev.cpuUsage + (Math.random() - 0.5) * 10)),
          memoryUsage: Math.max(0, Math.min(100, prev.memoryUsage + (Math.random() - 0.5) * 8)),
          networkActivity: Math.max(0, Math.min(100, prev.networkActivity + (Math.random() - 0.5) * 15)),
          activeConnections: Math.max(0, prev.activeConnections + Math.floor((Math.random() - 0.5) * 20)),
          responseTime: Math.max(100, prev.responseTime + Math.floor((Math.random() - 0.5) * 50)),
          errorRate: Math.max(0, Math.min(1, prev.errorRate + (Math.random() - 0.5) * 0.01))
        }))
      }, refreshInterval * 1000)

      return () => clearInterval(interval)
    }
  }, [autoRefresh, refreshInterval])

  const toggleWidget = (widgetName) => {
    setActiveWidgets(prev => ({
      ...prev,
      [widgetName]: !prev[widgetName]
    }))
  }

  const exportDashboard = () => {
    const dashboardData = {
      metrics: enhancedMetrics,
      realTimeData,
      phases: phases.map(p => ({
        name: p.name,
        progress: p.progress,
        status: p.status,
        tasks: p.tasks?.length || 0
      })),
      exportDate: new Date().toISOString()
    }

    const blob = new Blob([JSON.stringify(dashboardData, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `dashboard-export-${new Date().toISOString().split('T')[0]}.json`
    a.click()
  }

  const refreshDashboard = () => {
    // Simulate data refresh
    setRealTimeData(prev => ({
      ...prev,
      cpuUsage: Math.floor(Math.random() * 100),
      memoryUsage: Math.floor(Math.random() * 100),
      networkActivity: Math.floor(Math.random() * 100)
    }))
  }

  const MetricCard = ({ title, value, change, icon: Icon, color = 'blue', trend = 'up' }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className="text-3xl font-bold">{value}</p>
            {change && (
              <div className={`flex items-center mt-1 text-sm ${trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                {trend === 'up' ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                {change}
              </div>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`w-6 h-6 text-${color}-600`} />
          </div>
        </div>
      </CardContent>
    </Card>
  )

  const ChartWidget = ({ title, children, onToggleChart, chartType, onExport }) => (
    <Card className="hover:shadow-lg transition-shadow">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">{title}</CardTitle>
          <div className="flex items-center space-x-2">
            {onToggleChart && (
              <Button variant="ghost" size="sm" onClick={onToggleChart}>
                <BarChart3 className="w-4 h-4" />
              </Button>
            )}
            {onExport && (
              <Button variant="ghost" size="sm" onClick={onExport}>
                <Download className="w-4 h-4" />
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => setIsFullscreen(!isFullscreen)}>
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {children}
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      {/* Dashboard Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="w-5 h-5" />
                <span>Advanced Dashboard</span>
                <Badge variant="outline" className="ml-2">
                  <Signal className="w-3 h-3 mr-1" />
                  Live
                </Badge>
              </CardTitle>
              <CardDescription>
                Real-time project insights and performance analytics
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timeRanges.map(range => (
                    <SelectItem key={range.value} value={range.value}>
                      {range.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm" onClick={() => setDashboardLayout(dashboardLayout === 'grid' ? 'list' : 'grid')}>
                {dashboardLayout === 'grid' ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
              </Button>
              <Button variant="outline" size="sm" onClick={exportDashboard}>
                <Download className="w-4 h-4 mr-1" />
                Export
              </Button>
              <Button variant="outline" size="sm" onClick={refreshDashboard}>
                <RefreshCw className="w-4 h-4 mr-1" />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={autoRefresh}
                  onCheckedChange={setAutoRefresh}
                />
                <Label>Auto Refresh</Label>
              </div>
              <Select value={refreshInterval.toString()} onValueChange={(value) => setRefreshInterval(parseInt(value))}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10 seconds</SelectItem>
                  <SelectItem value="30">30 seconds</SelectItem>
                  <SelectItem value="60">1 minute</SelectItem>
                  <SelectItem value="300">5 minutes</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Clock className="w-4 h-4" />
              <span>Last updated: {new Date().toLocaleTimeString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics Overview */}
      {activeWidgets.overview && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <MetricCard
            title="Total Tasks"
            value={enhancedMetrics.totalTasks}
            change="+12%"
            icon={Target}
            color="blue"
          />
          <MetricCard
            title="Completed"
            value={enhancedMetrics.completedTasks}
            change="+8%"
            icon={CheckCircle}
            color="green"
          />
          <MetricCard
            title="In Progress"
            value={enhancedMetrics.inProgressTasks}
            change="+5%"
            icon={Activity}
            color="orange"
          />
          <MetricCard
            title="Overdue"
            value={enhancedMetrics.overdueTasks}
            change="-2%"
            icon={AlertTriangle}
            color="red"
            trend="down"
          />
          <MetricCard
            title="Team Efficiency"
            value={`${enhancedMetrics.teamEfficiency}%`}
            change="+3%"
            icon={Users}
            color="purple"
          />
          <MetricCard
            title="Risk Score"
            value={enhancedMetrics.riskScore}
            change="+5%"
            icon={Shield}
            color="indigo"
          />
        </div>
      )}

      {/* Real-time System Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Monitor className="w-5 h-5" />
            <span>System Performance</span>
            <Badge variant="outline" className={realTimeData.cpuUsage > 80 ? 'border-red-500 text-red-600' : 'border-green-500 text-green-600'}>
              {realTimeData.cpuUsage > 80 ? 'High Load' : 'Normal'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="relative w-20 h-20 mx-auto mb-2">
                <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="2"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="2"
                    strokeDasharray={`${realTimeData.cpuUsage}, 100`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold">{realTimeData.cpuUsage}%</span>
                </div>
              </div>
              <div className="flex items-center justify-center space-x-1">
                <Cpu className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium">CPU</span>
              </div>
            </div>

            <div className="text-center">
              <div className="relative w-20 h-20 mx-auto mb-2">
                <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="2"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2"
                    strokeDasharray={`${realTimeData.memoryUsage}, 100`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold">{realTimeData.memoryUsage}%</span>
                </div>
              </div>
              <div className="flex items-center justify-center space-x-1">
                <HardDrive className="w-4 h-4 text-green-600" />
                <span className="text-sm font-medium">Memory</span>
              </div>
            </div>

            <div className="text-center">
              <div className="relative w-20 h-20 mx-auto mb-2">
                <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 36 36">
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#e5e7eb"
                    strokeWidth="2"
                  />
                  <path
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="2"
                    strokeDasharray={`${realTimeData.networkActivity}, 100`}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-sm font-bold">{realTimeData.networkActivity}%</span>
                </div>
              </div>
              <div className="flex items-center justify-center space-x-1">
                <Wifi className="w-4 h-4 text-yellow-600" />
                <span className="text-sm font-medium">Network</span>
              </div>
            </div>

            <div className="text-center">
              <div className="space-y-2">
                <div className="text-2xl font-bold text-purple-600">{realTimeData.activeConnections}</div>
                <div className="flex items-center justify-center space-x-1">
                  <Globe className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">Connections</span>
                </div>
                <div className="text-xs text-gray-500">
                  {realTimeData.responseTime}ms avg response
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts Grid */}
      <div className={dashboardLayout === 'grid' ? 'grid grid-cols-1 lg:grid-cols-2 gap-6' : 'space-y-6'}>
        {/* Progress Chart */}
        {activeWidgets.progress && (
          <ChartWidget 
            title="Phase Progress Overview"
            chartType={chartTypes.progress}
            onToggleChart={() => setChartTypes(prev => ({ ...prev, progress: prev.progress === 'bar' ? 'line' : 'bar' }))}
          >
            <ResponsiveContainer width="100%" height={300}>
              {chartTypes.progress === 'bar' ? (
                <BarChart data={generateProgressData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="progress" fill="#3b82f6" name="Actual Progress" />
                  <Bar dataKey="planned" fill="#e5e7eb" name="Planned Progress" />
                </BarChart>
              ) : (
                <LineChart data={generateProgressData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="progress" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="planned" stroke="#e5e7eb" strokeWidth={2} strokeDasharray="5 5" />
                </LineChart>
              )}
            </ResponsiveContainer>
          </ChartWidget>
        )}

        {/* Timeline Chart */}
        {activeWidgets.timeline && (
          <ChartWidget 
            title="Activity Timeline"
            chartType={chartTypes.timeline}
            onToggleChart={() => setChartTypes(prev => ({ ...prev, timeline: prev.timeline === 'line' ? 'area' : 'line' }))}
          >
            <ResponsiveContainer width="100%" height={300}>
              {chartTypes.timeline === 'area' ? (
                <AreaChart data={generateTimelineData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey="completed" stackId="1" stroke="#10b981" fill="#10b981" />
                  <Area type="monotone" dataKey="started" stackId="1" stroke="#3b82f6" fill="#3b82f6" />
                  <Area type="monotone" dataKey="planned" stackId="1" stroke="#f59e0b" fill="#f59e0b" />
                </AreaChart>
              ) : (
                <LineChart data={generateTimelineData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="completed" stroke="#10b981" strokeWidth={2} />
                  <Line type="monotone" dataKey="started" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="planned" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" />
                </LineChart>
              )}
            </ResponsiveContainer>
          </ChartWidget>
        )}

        {/* Performance Metrics */}
        {activeWidgets.performance && (
          <ChartWidget title="Performance Metrics">
            <ResponsiveContainer width="100%" height={300}>
              <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="90%" data={generatePerformanceData()}>
                <RadialBar dataKey="value" cornerRadius={10} fill="#3b82f6" />
                <Tooltip />
              </RadialBarChart>
            </ResponsiveContainer>
          </ChartWidget>
        )}

        {/* Resource Allocation */}
        {activeWidgets.resources && (
          <ChartWidget title="Resource Allocation">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={generateResourceData()}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {generateResourceData().map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </ChartWidget>
        )}
      </div>

      {/* Widget Customization Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Dashboard Customization</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(activeWidgets).map(([widget, isActive]) => (
              <div key={widget} className="flex items-center justify-between p-3 border rounded">
                <span className="capitalize font-medium">{widget}</span>
                <Switch
                  checked={isActive}
                  onCheckedChange={() => toggleWidget(widget)}
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default AdvancedDashboard

