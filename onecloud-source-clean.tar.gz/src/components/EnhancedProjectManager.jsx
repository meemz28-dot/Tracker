import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog.jsx'
import { Calendar } from '@/components/ui/calendar.jsx'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover.jsx'
import { 
  Settings, 
  Users, 
  Calendar as CalendarIcon, 
  Clock, 
  Target, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  RefreshCw, 
  FileText, 
  BarChart3, 
  PieChart, 
  Activity, 
  Zap,
  Flag,
  MessageSquare,
  Bell,
  Eye,
  EyeOff,
  Download,
  Upload,
  Filter,
  Search,
  SortAsc,
  SortDesc,
  Grid,
  List,
  Calendar as CalendarView,
  Kanban,
  Timer,
  PlayCircle,
  PauseCircle,
  StopCircle,
  RotateCcw,
  Send,
  Paperclip,
  Star,
  Archive,
  Copy,
  ExternalLink
} from 'lucide-react'
import { format } from 'date-fns'
import { toast } from 'sonner'

const EnhancedProjectManager = ({ 
  phases, 
  setPhases, 
  isEditMode, 
  currentUser, 
  onPhaseUpdate,
  onTaskUpdate,
  metrics,
  setMetrics 
}) => {
  const [activeTab, setActiveTab] = useState('overview')
  const [viewMode, setViewMode] = useState('grid') // grid, list, calendar, kanban
  const [filterStatus, setFilterStatus] = useState('all')
  const [filterPriority, setFilterPriority] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [sortBy, setSortBy] = useState('dueDate')
  const [sortOrder, setSortOrder] = useState('asc')
  const [selectedPhase, setSelectedPhase] = useState(null)
  const [selectedTask, setSelectedTask] = useState(null)
  const [isTaskDialogOpen, setIsTaskDialogOpen] = useState(false)
  const [isPhaseDialogOpen, setIsPhaseDialogOpen] = useState(false)
  const [timeTracking, setTimeTracking] = useState({})
  const [comments, setComments] = useState({})
  const [newComment, setNewComment] = useState('')
  const [attachments, setAttachments] = useState({})

  // Enhanced task structure
  const [newTask, setNewTask] = useState({
    id: '',
    name: '',
    description: '',
    status: 'pending',
    priority: 'medium',
    assignedTo: '',
    assignedRole: '',
    dueDate: null,
    estimatedHours: 0,
    actualHours: 0,
    progress: 0,
    tags: [],
    dependencies: [],
    comments: [],
    attachments: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    createdBy: currentUser?.name || 'System',
    timeEntries: []
  })

  const [newPhase, setNewPhase] = useState({
    id: '',
    name: '',
    description: '',
    status: 'pending',
    priority: 'medium',
    startDate: '',
    endDate: '',
    progress: 0,
    responsiblePerson: '',
    responsibleFunction: '',
    budget: 0,
    actualCost: 0,
    risks: [],
    milestones: [],
    tasks: []
  })

  const statusOptions = [
    { value: 'pending', label: 'Pending', color: 'bg-gray-100 text-gray-800', icon: Clock },
    { value: 'in-progress', label: 'In Progress', color: 'bg-blue-100 text-blue-800', icon: PlayCircle },
    { value: 'completed', label: 'Completed', color: 'bg-green-100 text-green-800', icon: CheckCircle },
    { value: 'blocked', label: 'Blocked', color: 'bg-red-100 text-red-800', icon: AlertTriangle },
    { value: 'on-hold', label: 'On Hold', color: 'bg-yellow-100 text-yellow-800', icon: PauseCircle },
    { value: 'cancelled', label: 'Cancelled', color: 'bg-gray-100 text-gray-800', icon: StopCircle }
  ]

  const priorityOptions = [
    { value: 'low', label: 'Low', color: 'bg-green-100 text-green-800' },
    { value: 'medium', label: 'Medium', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'high', label: 'High', color: 'bg-orange-100 text-orange-800' },
    { value: 'critical', label: 'Critical', color: 'bg-red-100 text-red-800' }
  ]

  const teamMembers = [
    'Sarah Johnson', 'Michael Chen', 'David Wilson', 'Lisa Rodriguez',
    'Jennifer Park', 'Ahmed Al-Rashid', 'Robert Kim', 'Hassan Al-Mahmoud',
    'Omar Khalil', 'Priya Sharma', 'James Thompson', 'Fatima Al-Zahra',
    'Alex Martinez', 'Samantha Lee', 'Maria Gonzalez', 'Kevin Zhang',
    'Emma Watson'
  ]

  useEffect(() => {
    // Load saved data
    const savedTimeTracking = localStorage.getItem('timeTracking')
    const savedComments = localStorage.getItem('taskComments')
    const savedAttachments = localStorage.getItem('taskAttachments')

    if (savedTimeTracking) setTimeTracking(JSON.parse(savedTimeTracking))
    if (savedComments) setComments(JSON.parse(savedComments))
    if (savedAttachments) setAttachments(JSON.parse(savedAttachments))
  }, [])

  const generateId = () => {
    return Math.random().toString(36).substr(2, 9)
  }

  const getStatusInfo = (status) => {
    return statusOptions.find(option => option.value === status) || statusOptions[0]
  }

  const getPriorityInfo = (priority) => {
    return priorityOptions.find(option => option.value === priority) || priorityOptions[1]
  }

  const filteredPhases = phases.filter(phase => {
    const matchesSearch = phase.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         phase.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === 'all' || phase.status === filterStatus
    return matchesSearch && matchesStatus
  })

  const handleAddTask = (phaseId) => {
    const taskToAdd = {
      ...newTask,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    setPhases(prev => prev.map(phase => 
      phase.id === phaseId 
        ? { ...phase, tasks: [...(phase.tasks || []), taskToAdd] }
        : phase
    ))

    setNewTask({
      id: '',
      name: '',
      description: '',
      status: 'pending',
      priority: 'medium',
      assignedTo: '',
      assignedRole: '',
      dueDate: null,
      estimatedHours: 0,
      actualHours: 0,
      progress: 0,
      tags: [],
      dependencies: [],
      comments: [],
      attachments: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy: currentUser?.name || 'System',
      timeEntries: []
    })

    setIsTaskDialogOpen(false)
    toast.success('Task added successfully!')
    onTaskUpdate && onTaskUpdate()
  }

  const handleUpdateTask = (phaseId, taskId, updates) => {
    setPhases(prev => prev.map(phase => 
      phase.id === phaseId 
        ? {
            ...phase,
            tasks: (phase.tasks || []).map(task => 
              task.id === taskId 
                ? { ...task, ...updates, updatedAt: new Date().toISOString() }
                : task
            )
          }
        : phase
    ))
    onTaskUpdate && onTaskUpdate()
  }

  const handleDeleteTask = (phaseId, taskId) => {
    if (confirm('Are you sure you want to delete this task?')) {
      setPhases(prev => prev.map(phase => 
        phase.id === phaseId 
          ? { ...phase, tasks: (phase.tasks || []).filter(task => task.id !== taskId) }
          : phase
      ))
      toast.success('Task deleted successfully!')
      onTaskUpdate && onTaskUpdate()
    }
  }

  const handleAddPhase = () => {
    const phaseToAdd = {
      ...newPhase,
      id: generateId(),
      tasks: []
    }

    setPhases(prev => [...prev, phaseToAdd])
    setNewPhase({
      id: '',
      name: '',
      description: '',
      status: 'pending',
      priority: 'medium',
      startDate: '',
      endDate: '',
      progress: 0,
      responsiblePerson: '',
      responsibleFunction: '',
      budget: 0,
      actualCost: 0,
      risks: [],
      milestones: [],
      tasks: []
    })
    setIsPhaseDialogOpen(false)
    toast.success('Phase added successfully!')
    onPhaseUpdate && onPhaseUpdate()
  }

  const startTimeTracking = (taskId) => {
    setTimeTracking(prev => ({
      ...prev,
      [taskId]: {
        ...prev[taskId],
        isActive: true,
        startTime: new Date().toISOString(),
        currentSession: 0
      }
    }))
    toast.success('Time tracking started')
  }

  const stopTimeTracking = (taskId) => {
    const tracking = timeTracking[taskId]
    if (tracking && tracking.isActive) {
      const sessionTime = (new Date() - new Date(tracking.startTime)) / 1000 / 60 / 60 // hours
      setTimeTracking(prev => ({
        ...prev,
        [taskId]: {
          ...prev[taskId],
          isActive: false,
          totalTime: (prev[taskId]?.totalTime || 0) + sessionTime,
          sessions: [...(prev[taskId]?.sessions || []), {
            start: tracking.startTime,
            end: new Date().toISOString(),
            duration: sessionTime
          }]
        }
      }))
      toast.success(`Time tracking stopped. Session: ${sessionTime.toFixed(2)} hours`)
    }
  }

  const addComment = (taskId) => {
    if (!newComment.trim()) return

    const comment = {
      id: generateId(),
      text: newComment,
      author: currentUser?.name || 'Anonymous',
      timestamp: new Date().toISOString()
    }

    setComments(prev => ({
      ...prev,
      [taskId]: [...(prev[taskId] || []), comment]
    }))

    setNewComment('')
    toast.success('Comment added')
  }

  const calculatePhaseProgress = (phase) => {
    if (!phase.tasks || phase.tasks.length === 0) return phase.progress || 0
    
    const completedTasks = phase.tasks.filter(task => task.status === 'completed').length
    return Math.round((completedTasks / phase.tasks.length) * 100)
  }

  const getOverdueTasksCount = () => {
    let count = 0
    phases.forEach(phase => {
      if (phase.tasks) {
        phase.tasks.forEach(task => {
          if (task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed') {
            count++
          }
        })
      }
    })
    return count
  }

  const getTasksInProgress = () => {
    let count = 0
    phases.forEach(phase => {
      if (phase.tasks) {
        count += phase.tasks.filter(task => task.status === 'in-progress').length
      }
    })
    return count
  }

  if (!isEditMode) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Enhanced Project Manager</span>
          </CardTitle>
          <CardDescription>
            Advanced project management and task control
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Settings className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">Edit Mode Required</p>
            <p className="text-sm text-gray-500">
              Enable edit mode to access enhanced project management features.
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Project Manager Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5" />
                <span>Enhanced Project Manager</span>
                <Badge variant="outline" className="ml-2">
                  <Activity className="w-3 h-3 mr-1" />
                  Active
                </Badge>
              </CardTitle>
              <CardDescription>
                Advanced project management, task tracking, and team collaboration
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              >
                {viewMode === 'grid' ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
                {viewMode === 'grid' ? 'List' : 'Grid'} View
              </Button>
              <Dialog open={isPhaseDialogOpen} onOpenChange={setIsPhaseDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-1" />
                    Add Phase
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add New Phase</DialogTitle>
                    <DialogDescription>
                      Create a new project phase with detailed configuration
                    </DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Phase Name</Label>
                      <Input
                        value={newPhase.name}
                        onChange={(e) => setNewPhase(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Enter phase name"
                      />
                    </div>
                    <div>
                      <Label>Status</Label>
                      <Select value={newPhase.status} onValueChange={(value) => setNewPhase(prev => ({ ...prev, status: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {statusOptions.map(status => (
                            <SelectItem key={status.value} value={status.value}>
                              <div className="flex items-center space-x-2">
                                <status.icon className="w-4 h-4" />
                                <span>{status.label}</span>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2">
                      <Label>Description</Label>
                      <Textarea
                        value={newPhase.description}
                        onChange={(e) => setNewPhase(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Enter phase description"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label>Start Date</Label>
                      <Input
                        type="date"
                        value={newPhase.startDate}
                        onChange={(e) => setNewPhase(prev => ({ ...prev, startDate: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label>End Date</Label>
                      <Input
                        type="date"
                        value={newPhase.endDate}
                        onChange={(e) => setNewPhase(prev => ({ ...prev, endDate: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label>Responsible Person</Label>
                      <Select value={newPhase.responsiblePerson} onValueChange={(value) => setNewPhase(prev => ({ ...prev, responsiblePerson: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select person" />
                        </SelectTrigger>
                        <SelectContent>
                          {teamMembers.map(member => (
                            <SelectItem key={member} value={member}>{member}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Function/Role</Label>
                      <Input
                        value={newPhase.responsibleFunction}
                        onChange={(e) => setNewPhase(prev => ({ ...prev, responsibleFunction: e.target.value }))}
                        placeholder="Enter role or function"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2 mt-4">
                    <Button variant="outline" onClick={() => setIsPhaseDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddPhase}>
                      Add Phase
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold">{phases.length}</div>
                <div className="text-sm text-gray-500">Total Phases</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="w-5 h-5 text-green-600" />
              <div>
                <div className="text-2xl font-bold">{getTasksInProgress()}</div>
                <div className="text-sm text-gray-500">In Progress</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
              <div>
                <div className="text-2xl font-bold">{getOverdueTasksCount()}</div>
                <div className="text-sm text-gray-500">Overdue</div>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-purple-600" />
              <div>
                <div className="text-2xl font-bold">{teamMembers.length}</div>
                <div className="text-sm text-gray-500">Team Members</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2">
              <Search className="w-4 h-4 text-gray-500" />
              <Input
                placeholder="Search phases and tasks..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {statusOptions.map(status => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                {priorityOptions.map(priority => (
                  <SelectItem key={priority.value} value={priority.value}>
                    {priority.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-1" />
              More Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Phases Display */}
      <div className={viewMode === 'grid' ? 'grid grid-cols-1 lg:grid-cols-2 gap-6' : 'space-y-4'}>
        {filteredPhases.map(phase => {
          const statusInfo = getStatusInfo(phase.status)
          const StatusIcon = statusInfo.icon
          const progress = calculatePhaseProgress(phase)

          return (
            <Card key={phase.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <StatusIcon className="w-5 h-5" />
                    <CardTitle className="text-lg">{phase.name}</CardTitle>
                    <Badge className={statusInfo.color}>
                      {statusInfo.label}
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Button variant="ghost" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Dialog open={isTaskDialogOpen} onOpenChange={setIsTaskDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="ghost" size="sm" onClick={() => setSelectedPhase(phase)}>
                          <Plus className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl">
                        <DialogHeader>
                          <DialogTitle>Add Task to {selectedPhase?.name}</DialogTitle>
                          <DialogDescription>
                            Create a new task with detailed tracking and assignment
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Task Name</Label>
                            <Input
                              value={newTask.name}
                              onChange={(e) => setNewTask(prev => ({ ...prev, name: e.target.value }))}
                              placeholder="Enter task name"
                            />
                          </div>
                          <div>
                            <Label>Priority</Label>
                            <Select value={newTask.priority} onValueChange={(value) => setNewTask(prev => ({ ...prev, priority: value }))}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {priorityOptions.map(priority => (
                                  <SelectItem key={priority.value} value={priority.value}>
                                    {priority.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="col-span-2">
                            <Label>Description</Label>
                            <Textarea
                              value={newTask.description}
                              onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                              placeholder="Enter task description"
                              rows={3}
                            />
                          </div>
                          <div>
                            <Label>Assigned To</Label>
                            <Select value={newTask.assignedTo} onValueChange={(value) => setNewTask(prev => ({ ...prev, assignedTo: value }))}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select assignee" />
                              </SelectTrigger>
                              <SelectContent>
                                {teamMembers.map(member => (
                                  <SelectItem key={member} value={member}>{member}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label>Due Date</Label>
                            <Input
                              type="date"
                              value={newTask.dueDate || ''}
                              onChange={(e) => setNewTask(prev => ({ ...prev, dueDate: e.target.value }))}
                            />
                          </div>
                          <div>
                            <Label>Estimated Hours</Label>
                            <Input
                              type="number"
                              value={newTask.estimatedHours}
                              onChange={(e) => setNewTask(prev => ({ ...prev, estimatedHours: parseFloat(e.target.value) || 0 }))}
                              min="0"
                              step="0.5"
                            />
                          </div>
                          <div>
                            <Label>Role/Function</Label>
                            <Input
                              value={newTask.assignedRole}
                              onChange={(e) => setNewTask(prev => ({ ...prev, assignedRole: e.target.value }))}
                              placeholder="Enter role or function"
                            />
                          </div>
                        </div>
                        <div className="flex justify-end space-x-2 mt-4">
                          <Button variant="outline" onClick={() => setIsTaskDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={() => handleAddTask(selectedPhase?.id)}>
                            Add Task
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
                <CardDescription>{phase.description}</CardDescription>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>{phase.responsiblePerson} • {phase.responsibleFunction}</span>
                  <span>{phase.startDate} - {phase.endDate}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Progress</span>
                      <span className="text-sm text-gray-500">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>

                  {/* Tasks List */}
                  {phase.tasks && phase.tasks.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Tasks ({phase.tasks.length})</span>
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="space-y-1 max-h-32 overflow-y-auto">
                        {phase.tasks.slice(0, 3).map(task => {
                          const taskStatusInfo = getStatusInfo(task.status)
                          const taskPriorityInfo = getPriorityInfo(task.priority)
                          const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'completed'
                          const tracking = timeTracking[task.id]

                          return (
                            <div key={task.id} className="flex items-center justify-between p-2 border rounded text-sm">
                              <div className="flex items-center space-x-2 flex-1">
                                <Badge className={taskStatusInfo.color} variant="outline">
                                  {taskStatusInfo.label}
                                </Badge>
                                <span className={isOverdue ? 'text-red-600 font-medium' : ''}>{task.name}</span>
                                {task.priority !== 'medium' && (
                                  <Badge className={taskPriorityInfo.color} variant="outline">
                                    {taskPriorityInfo.label}
                                  </Badge>
                                )}
                                {isOverdue && <AlertTriangle className="w-4 h-4 text-red-500" />}
                              </div>
                              <div className="flex items-center space-x-1">
                                {tracking?.isActive ? (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => stopTimeTracking(task.id)}
                                    className="text-red-600"
                                  >
                                    <StopCircle className="w-4 h-4" />
                                  </Button>
                                ) : (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => startTimeTracking(task.id)}
                                    className="text-green-600"
                                  >
                                    <PlayCircle className="w-4 h-4" />
                                  </Button>
                                )}
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => setSelectedTask(task)}
                                >
                                  <Edit className="w-4 h-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteTask(phase.id, task.id)}
                                  className="text-red-600"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                          )
                        })}
                        {phase.tasks.length > 3 && (
                          <div className="text-center">
                            <Button variant="ghost" size="sm" className="text-blue-600">
                              View {phase.tasks.length - 3} more tasks
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Task Detail Dialog */}
      {selectedTask && (
        <Dialog open={!!selectedTask} onOpenChange={() => setSelectedTask(null)}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Edit className="w-5 h-5" />
                <span>Task Details: {selectedTask.name}</span>
              </DialogTitle>
            </DialogHeader>
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="time">Time Tracking</TabsTrigger>
                <TabsTrigger value="comments">Comments</TabsTrigger>
                <TabsTrigger value="attachments">Attachments</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Task Name</Label>
                    <Input value={selectedTask.name} readOnly />
                  </div>
                  <div>
                    <Label>Status</Label>
                    <Select value={selectedTask.status}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {statusOptions.map(status => (
                          <SelectItem key={status.value} value={status.value}>
                            {status.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2">
                    <Label>Description</Label>
                    <Textarea value={selectedTask.description || ''} rows={3} />
                  </div>
                  <div>
                    <Label>Assigned To</Label>
                    <Input value={selectedTask.assignedTo || ''} />
                  </div>
                  <div>
                    <Label>Due Date</Label>
                    <Input type="date" value={selectedTask.dueDate || ''} />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="time" className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {timeTracking[selectedTask.id]?.totalTime?.toFixed(1) || '0.0'}h
                        </div>
                        <div className="text-sm text-gray-500">Total Time</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {selectedTask.estimatedHours || 0}h
                        </div>
                        <div className="text-sm text-gray-500">Estimated</div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">
                          {timeTracking[selectedTask.id]?.sessions?.length || 0}
                        </div>
                        <div className="text-sm text-gray-500">Sessions</div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <div className="flex justify-center space-x-2">
                  {timeTracking[selectedTask.id]?.isActive ? (
                    <Button onClick={() => stopTimeTracking(selectedTask.id)} variant="destructive">
                      <StopCircle className="w-4 h-4 mr-2" />
                      Stop Tracking
                    </Button>
                  ) : (
                    <Button onClick={() => startTimeTracking(selectedTask.id)}>
                      <PlayCircle className="w-4 h-4 mr-2" />
                      Start Tracking
                    </Button>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="comments" className="space-y-4">
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {comments[selectedTask.id]?.map(comment => (
                    <div key={comment.id} className="border rounded p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{comment.author}</span>
                        <span className="text-sm text-gray-500">
                          {format(new Date(comment.timestamp), 'MMM dd, yyyy HH:mm')}
                        </span>
                      </div>
                      <p className="text-sm">{comment.text}</p>
                    </div>
                  )) || <p className="text-gray-500 text-center">No comments yet</p>}
                </div>
                
                <div className="flex space-x-2">
                  <Input
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    onKeyPress={(e) => e.key === 'Enter' && addComment(selectedTask.id)}
                  />
                  <Button onClick={() => addComment(selectedTask.id)}>
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="attachments" className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Paperclip className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-gray-500">Drag and drop files here or click to browse</p>
                  <Button variant="outline" className="mt-2">
                    <Upload className="w-4 h-4 mr-2" />
                    Choose Files
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}

export default EnhancedProjectManager

