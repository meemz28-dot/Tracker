import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { 
  Settings, 
  Palette, 
  Database, 
  Shield, 
  Bell, 
  Monitor, 
  Users, 
  FileText, 
  Download, 
  Upload, 
  RefreshCw, 
  Save, 
  Eye, 
  EyeOff,
  Trash2,
  Copy,
  Check,
  AlertTriangle,
  Info,
  Zap,
  Globe,
  Lock,
  Unlock,
  Calendar,
  Clock,
  BarChart3,
  PieChart,
  TrendingUp,
  Activity
} from 'lucide-react'
import { toast } from 'sonner'

const EnhancedAdminSettings = ({ 
  adminSettings, 
  setAdminSettings, 
  isEditMode, 
  currentUser,
  systemStats,
  onSettingsUpdate,
  onSystemAction 
}) => {
  const [activeTab, setActiveTab] = useState('appearance')
  const [unsavedChanges, setUnsavedChanges] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [backupHistory, setBackupHistory] = useState([])
  const [systemHealth, setSystemHealth] = useState({
    status: 'healthy',
    uptime: '99.9%',
    lastBackup: new Date().toISOString(),
    dataSize: '2.4 MB',
    activeUsers: 5,
    performance: 95
  })

  // Enhanced admin settings structure
  const [settings, setSettings] = useState({
    // Appearance Settings
    appearance: {
      primaryColor: '#E30613',
      secondaryColor: '#1B365D',
      accentColor: '#FFB81C',
      backgroundColor: '#FFFFFF',
      textColor: '#000000',
      borderRadius: 8,
      fontSize: 14,
      fontFamily: 'Inter',
      darkMode: false,
      compactMode: false,
      animations: true,
      customCSS: ''
    },
    // Branding Settings
    branding: {
      companyName: 'e& enterprise',
      logoUrl: '',
      faviconUrl: '',
      headerTitle: 'OneCloud Launch Tracker',
      footerText: 'Powered by e& enterprise',
      customBranding: true,
      showPoweredBy: true
    },
    // Security Settings
    security: {
      sessionTimeout: 30,
      maxLoginAttempts: 3,
      requireStrongPIN: false,
      enableTwoFactor: false,
      auditLogging: true,
      dataEncryption: true,
      autoLogout: true,
      ipWhitelist: [],
      securityNotifications: true
    },
    // Notification Settings
    notifications: {
      enableBrowser: true,
      enableEmail: false,
      enableSMS: false,
      soundEnabled: true,
      vibrationEnabled: true,
      quietHours: {
        enabled: false,
        start: '22:00',
        end: '08:00'
      },
      notificationTypes: {
        taskUpdates: true,
        deadlineReminders: true,
        systemAlerts: true,
        userActivity: false,
        dataChanges: true
      }
    },
    // Data Management
    dataManagement: {
      autoBackup: true,
      backupFrequency: 'daily',
      retentionPeriod: 30,
      compressionEnabled: true,
      cloudSync: false,
      exportFormat: 'json',
      dataValidation: true,
      versionControl: true
    },
    // Performance Settings
    performance: {
      cacheEnabled: true,
      lazyLoading: true,
      compressionEnabled: true,
      cdnEnabled: false,
      analyticsEnabled: true,
      debugMode: false,
      maxCacheSize: 50,
      refreshInterval: 30
    },
    // Integration Settings
    integrations: {
      apiEnabled: false,
      webhooksEnabled: false,
      ssoEnabled: false,
      ldapEnabled: false,
      slackIntegration: false,
      teamsIntegration: false,
      emailIntegration: false,
      calendarSync: false
    }
  })

  useEffect(() => {
    if (adminSettings) {
      setSettings(prev => ({
        ...prev,
        appearance: { 
          ...prev.appearance, 
          primaryColor: adminSettings.primaryColor,
          secondaryColor: adminSettings.secondaryColor,
          accentColor: adminSettings.accentColor,
        },
        branding: { 
          ...prev.branding, 
          companyName: adminSettings.companyName,
          logoUrl: adminSettings.logoUrl,
          faviconUrl: adminSettings.favicon,
          headerTitle: adminSettings.headerTitle || prev.branding.headerTitle,
          footerText: adminSettings.footerText || prev.branding.footerText,
        },
      }))
    }
  }, [adminSettings])

  const handleSettingChange = (category, key, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }))
    setUnsavedChanges(true)
  }

  const handleNestedSettingChange = (category, parentKey, childKey, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [parentKey]: {
          ...prev[category][parentKey],
          [childKey]: value
        }
      }
    }))
    setUnsavedChanges(true)
  }

  const saveSettings = async () => {
    setIsLoading(true)
    try {
      await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate API call
      setAdminSettings(settings)
      onSettingsUpdate && onSettingsUpdate(settings)
      setUnsavedChanges(false)
      toast.success('Settings saved successfully!')
    } catch (error) {
      toast.error('Failed to save settings')
    } finally {
      setIsLoading(false)
    }
  }

  const resetSettings = () => {
    if (confirm('Are you sure you want to reset all settings to defaults? This cannot be undone.')) {
      setSettings({
        appearance: {
          primaryColor: '#E30613',
          secondaryColor: '#1B365D',
          accentColor: '#FFB81C',
          backgroundColor: '#FFFFFF',
          textColor: '#000000',
          borderRadius: 8,
          fontSize: 14,
          fontFamily: 'Inter',
          darkMode: false,
          compactMode: false,
          animations: true,
          customCSS: ''
        },
        branding: {
          companyName: 'e& enterprise',
          logoUrl: '',
          faviconUrl: '',
          headerTitle: 'OneCloud Launch Tracker',
          footerText: 'Powered by e& enterprise',
          customBranding: true,
          showPoweredBy: true
        },
        security: {
          sessionTimeout: 30,
          maxLoginAttempts: 3,
          requireStrongPIN: false,
          enableTwoFactor: false,
          auditLogging: true,
          dataEncryption: true,
          autoLogout: true,
          ipWhitelist: [],
          securityNotifications: true
        },
        notifications: {
          enableBrowser: true,
          enableEmail: false,
          enableSMS: false,
          soundEnabled: true,
          vibrationEnabled: true,
          quietHours: {
            enabled: false,
            start: '22:00',
            end: '08:00'
          },
          notificationTypes: {
            taskUpdates: true,
            deadlineReminders: true,
            systemAlerts: true,
            userActivity: false,
            dataChanges: true
          }
        },
        dataManagement: {
          autoBackup: true,
          backupFrequency: 'daily',
          retentionPeriod: 30,
          compressionEnabled: true,
          cloudSync: false,
          exportFormat: 'json',
          dataValidation: true,
          versionControl: true
        },
        performance: {
          cacheEnabled: true,
          lazyLoading: true,
          compressionEnabled: true,
          cdnEnabled: false,
          analyticsEnabled: true,
          debugMode: false,
          maxCacheSize: 50,
          refreshInterval: 30
        },
        integrations: {
          apiEnabled: false,
          webhooksEnabled: false,
          ssoEnabled: false,
          ldapEnabled: false,
          slackIntegration: false,
          teamsIntegration: false,
          emailIntegration: false,
          calendarSync: false
        }
      })
      setUnsavedChanges(true)
      toast.info('Settings reset to defaults')
    }
  }

  const exportSettings = () => {
    const dataToExport = {
      settings,
      exportDate: new Date().toISOString(),
      version: '2.0.0'
    }
    const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `admin-settings-${new Date().toISOString().split('T')[0]}.json`
    a.click()
    toast.success('Settings exported successfully!')
  }

  const importSettings = (event) => {
    const file = event.target.files[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result)
          if (data.settings) {
            setSettings(data.settings)
            setUnsavedChanges(true)
            toast.success('Settings imported successfully!')
          } else {
            toast.error('Invalid settings file format')
          }
        } catch (error) {
          toast.error('Failed to import settings')
        }
      }
      reader.readAsText(file)
    }
  }

  const createBackup = async () => {
    setIsLoading(true)
    try {
      await new Promise(resolve => setTimeout(resolve, 1500))
      const backup = {
        id: Date.now(),
        date: new Date().toISOString(),
        size: '2.4 MB',
        type: 'manual'
      }
      setBackupHistory(prev => [backup, ...prev.slice(0, 9)])
      toast.success('Backup created successfully!')
    } catch (error) {
      toast.error('Failed to create backup')
    } finally {
      setIsLoading(false)
    }
  }

  if (!isEditMode || currentUser?.role !== 'admin') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Enhanced Admin Settings</span>
          </CardTitle>
          <CardDescription>
            Advanced administrative controls and system configuration
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <Lock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-2">Access Restricted</p>
            <p className="text-sm text-gray-500">
              Enhanced admin settings require administrator privileges and edit mode to be enabled.
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header with Actions */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Settings className="w-5 h-5" />
                <span>Enhanced Admin Settings</span>
                {unsavedChanges && (
                  <Badge variant="outline" className="ml-2">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    Unsaved Changes
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Advanced administrative controls and system configuration
              </CardDescription>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAdvanced(!showAdvanced)}
              >
                {showAdvanced ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                {showAdvanced ? 'Hide' : 'Show'} Advanced
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportSettings}
              >
                <Download className="w-4 h-4 mr-1" />
                Export
              </Button>
              <label className="cursor-pointer">
                <Button variant="outline" size="sm" asChild>
                  <span>
                    <Upload className="w-4 h-4 mr-1" />
                    Import
                  </span>
                </Button>
                <input
                  type="file"
                  accept=".json"
                  className="hidden"
                  onChange={importSettings}
                />
              </label>
              <Button
                variant="destructive"
                size="sm"
                onClick={resetSettings}
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Reset
              </Button>
              <Button
                onClick={saveSettings}
                disabled={!unsavedChanges || isLoading}
                size="sm"
              >
                {isLoading ? (
                  <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
                ) : (
                  <Save className="w-4 h-4 mr-1" />
                )}
                Save Changes
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* System Health Dashboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="w-5 h-5" />
            <span>System Health</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{systemHealth.uptime}</div>
              <div className="text-sm text-gray-500">Uptime</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{systemHealth.activeUsers}</div>
              <div className="text-sm text-gray-500">Active Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{systemHealth.dataSize}</div>
              <div className="text-sm text-gray-500">Data Size</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2">
                <div className="text-2xl font-bold text-orange-600">{systemHealth.performance}%</div>
              </div>
              <div className="text-sm text-gray-500">Performance</div>
              <Progress value={systemHealth.performance} className="mt-1" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Settings Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="appearance" className="flex items-center space-x-1">
            <Palette className="w-4 h-4" />
            <span className="hidden sm:inline">Appearance</span>
          </TabsTrigger>
          <TabsTrigger value="branding" className="flex items-center space-x-1">
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">Branding</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center space-x-1">
            <Shield className="w-4 h-4" />
            <span className="hidden sm:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center space-x-1">
            <Bell className="w-4 h-4" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="data" className="flex items-center space-x-1">
            <Database className="w-4 h-4" />
            <span className="hidden sm:inline">Data</span>
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center space-x-1">
            <Zap className="w-4 h-4" />
            <span className="hidden sm:inline">Performance</span>
          </TabsTrigger>
          <TabsTrigger value="integrations" className="flex items-center space-x-1">
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">Integrations</span>
          </TabsTrigger>
        </TabsList>

        {/* Appearance Settings */}
        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Visual Appearance</CardTitle>
              <CardDescription>Customize the visual appearance and theme</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Primary Color</Label>
                    <div className="flex items-center space-x-2 mt-1">
                      <Input
                        type="color"
                        value={settings.appearance.primaryColor}
                        onChange={(e) => handleSettingChange('appearance', 'primaryColor', e.target.value)}
                        className="w-12 h-10"
                      />
                      <Input
                        value={settings.appearance.primaryColor}
                        onChange={(e) => handleSettingChange('appearance', 'primaryColor', e.target.value)}
                        placeholder="#E30613"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Secondary Color</Label>
                    <div className="flex items-center space-x-2 mt-1">
                      <Input
                        type="color"
                        value={settings.appearance.secondaryColor}
                        onChange={(e) => handleSettingChange('appearance', 'secondaryColor', e.target.value)}
                        className="w-12 h-10"
                      />
                      <Input
                        value={settings.appearance.secondaryColor}
                        onChange={(e) => handleSettingChange('appearance', 'secondaryColor', e.target.value)}
                        placeholder="#1B365D"
                      />
                    </div>
                  </div>
                  <div>
                    <Label>Accent Color</Label>
                    <div className="flex items-center space-x-2 mt-1">
                      <Input
                        type="color"
                        value={settings.appearance.accentColor}
                        onChange={(e) => handleSettingChange('appearance', 'accentColor', e.target.value)}
                        className="w-12 h-10"
                      />
                      <Input
                        value={settings.appearance.accentColor}
                        onChange={(e) => handleSettingChange('appearance', 'accentColor', e.target.value)}
                        placeholder="#FFB81C"
                      />
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label>Font Family</Label>
                    <Select 
                      value={settings.appearance.fontFamily} 
                      onValueChange={(value) => handleSettingChange('appearance', 'fontFamily', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Inter">Inter</SelectItem>
                        <SelectItem value="Roboto">Roboto</SelectItem>
                        <SelectItem value="Open Sans">Open Sans</SelectItem>
                        <SelectItem value="Lato">Lato</SelectItem>
                        <SelectItem value="Poppins">Poppins</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Font Size: {settings.appearance.fontSize}px</Label>
                    <Slider
                      value={[settings.appearance.fontSize]}
                      onValueChange={(value) => handleSettingChange('appearance', 'fontSize', value[0])}
                      min={12}
                      max={20}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label>Border Radius: {settings.appearance.borderRadius}px</Label>
                    <Slider
                      value={[settings.appearance.borderRadius]}
                      onValueChange={(value) => handleSettingChange('appearance', 'borderRadius', value[0])}
                      min={0}
                      max={20}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center justify-between">
                  <Label>Dark Mode</Label>
                  <Switch
                    checked={settings.appearance.darkMode}
                    onCheckedChange={(checked) => handleSettingChange('appearance', 'darkMode', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Compact Mode</Label>
                  <Switch
                    checked={settings.appearance.compactMode}
                    onCheckedChange={(checked) => handleSettingChange('appearance', 'compactMode', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Animations</Label>
                  <Switch
                    checked={settings.appearance.animations}
                    onCheckedChange={(checked) => handleSettingChange('appearance', 'animations', checked)}
                  />
                </div>
              </div>

              {showAdvanced && (
                <div>
                  <Label>Custom CSS</Label>
                  <Textarea
                    value={settings.appearance.customCSS}
                    onChange={(e) => handleSettingChange('appearance', 'customCSS', e.target.value)}
                    placeholder="/* Add custom CSS here */"
                    rows={6}
                    className="mt-1 font-mono text-sm"
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Branding Settings */}
        <TabsContent value="branding" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Brand Identity</CardTitle>
              <CardDescription>Customize your organization's branding and identity</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Company Name</Label>
                    <Input
                      value={settings.branding.companyName}
                      onChange={(e) => handleSettingChange('branding', 'companyName', e.target.value)}
                      placeholder="e& enterprise"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label>Header Title</Label>
                    <Input
                      value={settings.branding.headerTitle}
                      onChange={(e) => handleSettingChange('branding', 'headerTitle', e.target.value)}
                      placeholder="OneCloud Launch Tracker"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label>Footer Text</Label>
                    <Input
                      value={settings.branding.footerText}
                      onChange={(e) => handleSettingChange('branding', 'footerText', e.target.value)}
                      placeholder="Powered by e& enterprise"
                      className="mt-1"
                    />
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label>Company Logo</Label>
                    <div className="mt-1 space-y-2">
                      {settings.branding.logoUrl && (
                        <div className="border rounded-lg p-4 bg-gray-50">
                          <img 
                            src={settings.branding.logoUrl} 
                            alt="Company Logo" 
                            className="max-h-16 max-w-full object-contain"
                          />
                        </div>
                      )}
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          onClick={() => document.getElementById('logo-upload').click()}
                          className="flex items-center space-x-2"
                        >
                          <Upload className="w-4 h-4" />
                          <span>Upload Logo</span>
                        </Button>
                        <input
                          id="logo-upload"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files[0]
                            if (file) {
                              const reader = new FileReader()
                              reader.onload = (event) => {
                                handleSettingChange('branding', 'logoUrl', event.target.result)
                                toast.success('Logo uploaded successfully!')
                              }
                              reader.readAsDataURL(file)
                            }
                          }}
                          className="hidden"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <Label>Favicon</Label>
                    <div className="mt-1 space-y-2">
                      {settings.branding.faviconUrl && (
                        <div className="border rounded-lg p-4 bg-gray-50">
                          <img 
                            src={settings.branding.faviconUrl} 
                            alt="Favicon" 
                            className="w-8 h-8 object-contain"
                          />
                        </div>
                      )}
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          onClick={() => document.getElementById('favicon-upload').click()}
                          className="flex items-center space-x-2"
                        >
                          <Upload className="w-4 h-4" />
                          <span>Upload Favicon</span>
                        </Button>
                        <input
                          id="favicon-upload"
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files[0]
                            if (file) {
                              const reader = new FileReader()
                              reader.onload = (event) => {
                                handleSettingChange('branding', 'faviconUrl', event.target.result)
                                toast.success('Favicon uploaded successfully!')
                              }
                              reader.readAsDataURL(file)
                            }
                          }}
                          className="hidden"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Custom Branding</Label>
                    <p className="text-sm text-gray-500">Enable custom branding throughout the application</p>
                  </div>
                  <Switch
                    checked={settings.branding.customBranding}
                    onCheckedChange={(checked) => handleSettingChange('branding', 'customBranding', checked)}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Show "Powered By"</Label>
                    <p className="text-sm text-gray-500">Display attribution in the footer</p>
                  </div>
                  <Switch
                    checked={settings.branding.showPoweredBy}
                    onCheckedChange={(checked) => handleSettingChange('branding', 'showPoweredBy', checked)}
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Brand Preview</h4>
                    <p className="text-sm text-gray-500">Preview how your branding will appear</p>
                  </div>
                  <Button onClick={saveSettings} className="flex items-center space-x-2">
                    <Save className="w-4 h-4" />
                    <span>Apply Branding</span>
                  </Button>
                </div>
                
                <div className="mt-4 p-4 border rounded-lg bg-gray-50">
                  <div className="flex items-center space-x-3 mb-2">
                    {settings.branding.logoUrl && (
                      <img 
                        src={settings.branding.logoUrl} 
                        alt="Logo Preview" 
                        className="h-8 object-contain"
                      />
                    )}
                    <h3 className="text-lg font-semibold">{settings.branding.headerTitle}</h3>
                  </div>
                  <p className="text-sm text-gray-600">{settings.branding.companyName}</p>
                  {settings.branding.showPoweredBy && (
                    <p className="text-xs text-gray-500 mt-2">{settings.branding.footerText}</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Configuration</CardTitle>
              <CardDescription>Manage security settings and access controls</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label>Session Timeout (minutes)</Label>
                    <Input
                      type="number"
                      value={settings.security.sessionTimeout}
                      onChange={(e) => handleSettingChange('security', 'sessionTimeout', parseInt(e.target.value))}
                      min={5}
                      max={480}
                    />
                  </div>
                  <div>
                    <Label>Max Login Attempts</Label>
                    <Input
                      type="number"
                      value={settings.security.maxLoginAttempts}
                      onChange={(e) => handleSettingChange('security', 'maxLoginAttempts', parseInt(e.target.value))}
                      min={1}
                      max={10}
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Require Strong PIN</Label>
                    <Switch
                      checked={settings.security.requireStrongPIN}
                      onCheckedChange={(checked) => handleSettingChange('security', 'requireStrongPIN', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Enable Two-Factor Auth</Label>
                    <Switch
                      checked={settings.security.enableTwoFactor}
                      onCheckedChange={(checked) => handleSettingChange('security', 'enableTwoFactor', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Audit Logging</Label>
                    <Switch
                      checked={settings.security.auditLogging}
                      onCheckedChange={(checked) => handleSettingChange('security', 'auditLogging', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Data Encryption</Label>
                    <Switch
                      checked={settings.security.dataEncryption}
                      onCheckedChange={(checked) => handleSettingChange('security', 'dataEncryption', checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Data Management */}
        <TabsContent value="data" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
              <CardDescription>Backup, export, and data management settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Auto Backup</Label>
                    <Switch
                      checked={settings.dataManagement.autoBackup}
                      onCheckedChange={(checked) => handleSettingChange('dataManagement', 'autoBackup', checked)}
                    />
                  </div>
                  <div>
                    <Label>Backup Frequency</Label>
                    <Select 
                      value={settings.dataManagement.backupFrequency} 
                      onValueChange={(value) => handleSettingChange('dataManagement', 'backupFrequency', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Retention Period (days)</Label>
                    <Input
                      type="number"
                      value={settings.dataManagement.retentionPeriod}
                      onChange={(e) => handleSettingChange('dataManagement', 'retentionPeriod', parseInt(e.target.value))}
                      min={1}
                      max={365}
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <Button onClick={createBackup} disabled={isLoading} className="w-full">
                    {isLoading ? (
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Database className="w-4 h-4 mr-2" />
                    )}
                    Create Manual Backup
                  </Button>
                  <div className="space-y-2">
                    <Label>Recent Backups</Label>
                    <div className="space-y-1 max-h-32 overflow-y-auto">
                      {backupHistory.length > 0 ? (
                        backupHistory.map(backup => (
                          <div key={backup.id} className="flex items-center justify-between text-sm p-2 border rounded">
                            <span>{new Date(backup.date).toLocaleDateString()}</span>
                            <span className="text-gray-500">{backup.size}</span>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500">No backups available</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Settings */}
        <TabsContent value="performance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Performance Optimization</CardTitle>
              <CardDescription>Configure performance and caching settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Enable Caching</Label>
                    <Switch
                      checked={settings.performance.cacheEnabled}
                      onCheckedChange={(checked) => handleSettingChange('performance', 'cacheEnabled', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Lazy Loading</Label>
                    <Switch
                      checked={settings.performance.lazyLoading}
                      onCheckedChange={(checked) => handleSettingChange('performance', 'lazyLoading', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Compression</Label>
                    <Switch
                      checked={settings.performance.compressionEnabled}
                      onCheckedChange={(checked) => handleSettingChange('performance', 'compressionEnabled', checked)}
                    />
                  </div>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label>Max Cache Size (MB): {settings.performance.maxCacheSize}</Label>
                    <Slider
                      value={[settings.performance.maxCacheSize]}
                      onValueChange={(value) => handleSettingChange('performance', 'maxCacheSize', value[0])}
                      min={10}
                      max={500}
                      step={10}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label>Refresh Interval (seconds): {settings.performance.refreshInterval}</Label>
                    <Slider
                      value={[settings.performance.refreshInterval]}
                      onValueChange={(value) => handleSettingChange('performance', 'refreshInterval', value[0])}
                      min={5}
                      max={300}
                      step={5}
                      className="mt-2"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default EnhancedAdminSettings

